# Tahap 3 Budget Management

Tanggal penyusunan dan akses harga: 3 November 2026. Organisasi dan transaksi bersifat simulasi. Anggaran ini menilai alokasi sumber daya perusahaan untuk MVP batch AI Project Risk Monitoring, bukan pengeluaran pribadi Naufal atau biaya aplikasi produksi penuh.

## Keputusan dan hasil

| Komponen | IDR dibulatkan |
|---|---:|
| Direct labor dan employer budget allowances untuk 87 jam | 17.919.334 |
| Reserve berbasis 15 jam risiko rework | 1.820.548 |
| BAC termasuk reserve | 19.739.882 |
| AC alokasi SIMULASI sampai 27 Januari 2027 | 13.569.317 |
| ETC Base | 6.570.750 |
| EAC Base | 20.140.067 |
| Forecast overrun terhadap BAC | 400.185 |
| Forecast overrun persentase | 2,03% |
| Budget utilization | 68,74% |

Nilai workbook tidak dibulatkan pada perhitungan antara. Selisih satu rupiah pada penjumlahan angka tampilan dapat timbul dari pembulatan total. AC bukan invoice atau pembayaran; merupakan alokasi biaya timesheet dummy. Tidak ada uang dikeluarkan, kontrak dibuat, atau pegawai dibayar melalui penugasan ini.

## Rekonsiliasi dengan Tahap 2

WBS tetap 28 task dan 93 jam. T26 halaman portofolio serta T28 CV/interview berjumlah 6 jam; keduanya tidak dibebankan kepada perusahaan karena merupakan kegiatan melamar kerja pribadi. Lingkup anggaran perusahaan menjadi 87 jam. Nilai ekonomi enam jam tersebut pada proxy PMO adalah Rp1.951.425 dan ditampilkan terpisah, bukan ditambahkan ke BAC. T27 repository dan dokumentasi reproduksi tetap di lingkup karena merupakan kebutuhan handover teknis. Power BI tetap 0 jam dan ditunda. Tidak mengubah tanggal, dependency, WBS, atau scope di Jira Tahap 2.

Rencana ini adalah MVP internal, bukan penawaran sistem enterprise. Usaha teknis yang awalnya kecil dan porsi dokumen PMO yang besar mengikuti WBS portofolio yang sudah ada. Bila kelayakan data atau kebutuhan produksi menuntut pekerjaan lebih besar, gunakan change request; jangan mengklaim 87 jam cukup untuk semua implementasi perusahaan.

## Cara memperoleh tarif

| Role alokasi | Benchmark bulanan IDR | Pemakaian dan batas |
|---|---:|---|
| PMO | 45.000.000 | Michael Page Project Manager; proxy fungsi pengendalian PM senior, bukan gaji FG atau estimasi khusus PMO Analyst Bandung. |
| Finance | 37.500.000 | Michael Page Finance Manager; proxy review keuangan internal, bukan tarif staf junior. |
| Security | 7.550.000 | Median terkait NodeFlair; bukan quote security vendor. |
| Data | 9.000.000 | Median terkait NodeFlair Data Engineer. |
| ML | 10.000.000 | Median terkait NodeFlair Data Scientist; bukan penetapan algoritma. |
| Operations | 11.500.000 | Median terkait NodeFlair DevOps; dipakai sebagai proxy handover teknis. |

Benchmark dari penerbit berbeda tidak identik seniority, industri, kota atau ukuran sampelnya. Variasi tersebut dijelaskan, bukan dipresentasikan sebagai enam harga pasar pasti yang setara. Model memilih alokasi employee existing, tidak merekrut enam pegawai penuh waktu. Sumber Michael Page menyatakan benchmark berasal dari placement dan advertised roles serta belum memasukkan bonus atau benefit. NodeFlair menjelaskan data kontribusi gaji dan lowongan yang dikurasi; kesegaran masing-masing observasi dapat bervariasi.

Tarif jam dihitung dari biaya bulanan dibagi asumsi 160 jam produktif per bulan (20 hari x 8 jam). Ini alokasi biaya internal, bukan aturan hukum konversi gaji atau tarif freelance. Tambahan employer budgeting meliputi akrual THR 1/12, JHT 3,7%, JKK risiko kantor 0,24%, JKM 0,3%, health 4% dengan cap gaji Rp12 juta, serta JP ceiling 2% dari full salary.

JP sengaja tidak diberi cap pada model agar menjadi batas anggaran konservatif. Nilainya bukan tagihan payroll aktual: cap JP dan aturan payroll 2027 harus divalidasi HR sebelum penggunaan untuk pembayaran. Klasifikasi risiko kantor, masa kerja existing minimal 12 bulan untuk THR, serta asumsi dasar gaji dan tunjangan tetap merupakan asumsi model. Employee deductions tidak ditambahkan lagi sebagai biaya employer. JKP tidak diberi charge ekstra pada model. PPh employee tidak digross-up. Tidak mengarang pajak pengadaan karena tidak ada pembelian baru dalam base case.

## Kebutuhan tools dan infrastruktur

- Jira memakai asumsi paket Free dalam batas sampai 10 pengguna dan 2GB. Halaman harga diperiksa; billing akun pribadi tidak diperiksa.
- Python dan scikit-learn menggunakan lisensi open source; engine direncanakan berjalan di CPU lokal. Tidak perlu membeli GPU, sewa VM, API LLM, domain atau hosting untuk batch lokal ini.
- Halaman dataset Mendeley v2 menunjukkan CC BY 4.0 dan kebutuhan atribusi. Pemeriksaan lisensi ini tidak berarti file unggahan dicocokkan ulang atau datanya dinyatakan layak prediksi.
- Excel dan dokumen memakai lisensi perusahaan existing sebagai asumsi; kepemilikan lisensi user belum diaudit. Alternatif Microsoft 365 Business Basic tanpa Teams di halaman Indonesia adalah USD3,24 per seat per bulan dengan langganan bulanan sebelum pajak, dibanding USD2,70 pada komitmen tahunan. Angka ini adalah price-book alternatif, tidak dibeli, tidak dikonversi atau dimasukkan sebagai biaya seolah sudah diperlukan.
- Laptop, Windows, internet, listrik dan kantor diasumsikan fasilitas existing. Tidak ada procurement tambahan. Biaya bersama dan depresiasi tidak dialokasikan tanpa meter, kontrak atau kebijakan cost center. Jadi anggaran ini bukan full company TCO dan tidak mengklaim fasilitas tersebut bernilai nol.

## Skenario pengendalian biaya

Cutoff adalah 27 Januari 2027, di dalam timeline dummy. Enam belas catatan timesheet SIM-TS merepresentasikan T01 sampai T16; diasumsikan pekerjaan tersebut selesai dalam cerita simulasi. T15 dan T16 masing-masing menggunakan 9 jam dibanding rencana 6 jam akibat pemeriksaan baseline dan penyiapan snapshot. Deviasi actual simulasi berjumlah 6 jam Data, senilai Rp400.185.

Untuk pekerjaan tersisa, jam inti berasal dari baseline yang belum dikonsumsi. Tambahan rework masa depan:

| Skenario | Data | ML | PMO | EAC IDR dibulatkan |
|---|---:|---:|---:|---:|
| Optimistic | 3 jam | 3 jam | 0 jam | 18.741.937 |
| Base | 6 jam | 6 jam | 3 jam | 20.140.067 |
| Pessimistic | 12 jam | 12 jam | 6 jam | 21.960.614 |

Jam rework adalah asumsi skenario yang diperbolehkan user, bukan angka pasar atau hasil penelitian empiris. Reserve baseline berisi 6 jam Data, 6 jam ML dan 3 jam PMO. Dalam EAC, gunakan biaya rework skenario terpilih; reserve tidak ditambahkan sekali lagi. AC sama di semua skenario. Ada satu skenario aktif per reporting cutoff melalui Rates!B13; default Base.

Rekomendasi PMO simulasi: laporkan forecast overrun 2,03% terhadap BAC dan validasi kebutuhan rework sebelum menyetujui tambahan alokasi. Opsi kerja yang lebih ringan dapat menghasilkan EAC Optimistic di bawah BAC, tetapi tidak boleh menghapus kontrol leakage, validasi input atau QA demi menekan biaya. Tidak ada klaim penghematan aktual dari opsi tersebut. Rework yang menambah usaha dapat berdampak pada tanggal selesai; jadwal tidak diubah otomatis, perubahan harus dievaluasi saat decision/recovery planning.

## Definisi dan penggunaan workbook

1. Summary menghubungkan hasil baseline, AC, ETC, EAC, VAC, utilization dan perbandingan skenario.
2. Baseline menyimpan tarif snapshot pada 3 November 2026 dan reserve yang dibekukan. Perubahan benchmark pada Rates tidak mengubah BAC.
3. Actuals menyimpan rate snapshot dan identitas SIM-TS; perubahan benchmark atau selector skenario tidak mengubah AC historis. Actual ini tidak terhubung ke status eksekusi Jira dan bukan bukti pekerjaan model sudah dilakukan.
4. Rates memuat benchmark, konversi, parameter employer dan jam rework. Mengubah rate mengubah forecast, dengan asumsi biaya waktu pekerjaan tersisa memakai rate baru.
5. Forecast memakai cutoff untuk menyaring AC, menghitung remaining core, tambahan risiko dan ETC. Rumus memakai 16 baris ledger contoh; bila menambah transaksi, perlu memperluas range yang dirujuk. Tidak mengklaim workflow append otomatis.
6. Needs_Sources memuat daftar kebutuhan, harga alternatif, URL, unit, penerbit, dan keterbatasan sumber.

CPI, SPI dan CV Earned Value tidak dihitung karena earned value yang sah belum tersedia. AC lebih rendah dari BAC tidak berarti proyek hemat: pembanding untuk biaya akhir adalah EAC. Tanggal simulasi 2027 menggunakan harga dan benchmark yang dibekukan saat riset; bukan janji harga 2027. Perubahan kapasitas, tarif, scope atau lisensi memerlukan review dan versi baseline baru bila memengaruhi BAC.

## Referensi utama

- S01 https://www.michaelpage.co.id/salary-comparison-tool/project-manager-salaries
- S02 https://www.michaelpage.co.id/salary-comparison-tool/finance-manager-salaries
- S03 https://nodeflair.com/salaries/indonesia-devops-engineer-salary
- S04 https://www.bpjsketenagakerjaan.go.id/artikel/18913/artikel-berapa-besaran-iuran-jht%2C-jkk%2C-jkm%2C-jp-dan-jkp
- S05 https://jdih.kemnaker.go.id/peraturan/detail/2983/surat-edaran-menteri-nomor-3-tahun-2026
- S06 https://peraturan.bpk.go.id/Details/136650
- S07 https://disdik.slemankab.go.id/pemberitahuan-iuran-bpjs-pegawai-pemerintah-dengan-perjanjian-kerja-paruh-waktu-pppk-pw/
- S08 https://www.atlassian.com/software/jira/pricing
- S09 https://www.microsoft.com/id-id/microsoft-365/business/microsoft-365-business-basic
- S10 https://data.mendeley.com/datasets/2p5sz57wh2/2
- S11 https://docs.python.org/3/license.html
- S12 https://scikit-learn.org/stable/faq.html
- S13 Workbook dan backlog Tahap 2 yang sudah dibuat.

## Log pelaksanaan kepada Naufal

1. Membaca ulang backlog Tahap 2 dan menjaga rekonsiliasi 93 jam.
2. Mencari referensi harga dan salary benchmark; mengutamakan sumber penerbit/provider. Beberapa panduan PDF tidak dapat diakses; angka yang tidak berhasil diverifikasi tidak dipakai sebagai input.
3. Memisahkan kebutuhan perusahaan, kegiatan pribadi portofolio, tools gratis, fasilitas existing dan pengadaan opsional.
4. Menyusun workbook enam sheet dengan baseline snapshot, actual dummy, tiga forecast, KPI, kebutuhan dan sumber.
5. Memeriksa hasil menggunakan hitungan terpisah: labor, reserve, BAC, AC dan EAC cocok sampai toleransi Rp0,01. Selector skenario mengubah EAC tanpa mengubah AC. Perubahan benchmark mengubah forecast, sedangkan BAC dan actual tetap. Nilai nol pada kapasitas invalid menampilkan error pembagian, tidak menyamar sebagai budget nol sehat; parameter dikembalikan ke 160 sebelum ekspor. Scan final tidak menemukan error formula.
6. Memeriksa tampilan setiap worksheet. File belum diuji langsung di Excel Windows; verifikasi kalkulasi dilakukan pada engine pembuat workbook dan hitungan terpisah.
7. Memperbarui KAN-20, KAN-21 dan KAN-22 di Jira dengan ringkasan hasil dan memindahkannya ke In Review. Tidak mengubah jadwal, memasukkan actual fiktif ke Jira worklog, atau menyatakan model selesai. Tahap 4-8 tetap backlog.

Status: Tahap 3 selesai disusun dan diperiksa untuk review owner. Tidak ada pembelian, training, pengolahan ulang dataset, implementasi dashboard, atau pelaksanaan Tahap 4 dalam penugasan ini.
