# Tahap 4 — RAID, Risk Management dan AI Governance

**AI Project Risk Monitoring — Independent Simulation Project**  
Versi 1.0 · Snapshot simulasi: **21 Januari 2027** · Disusun aktual: **3 November 2026**  
Status: selesai disusun dan diperiksa, menunggu review isi oleh Naufal.

## Dasar dan batas snapshot

Snapshot awal ditempatkan pada akhir WBS 4.3 dalam baseline Tahap 2. Tanggal simulasi adalah posisi dalam cerita proyek, bukan tanggal pekerjaan nyata. Temuan dari audit lama dibawa sebagai informasi yang sudah tersedia sebelum pelaksanaan baseline baru. Temuan tersebut tidak membuktikan bahwa Tahap 5 pada baseline baru telah dilaksanakan.

RAID hanya berisi hal yang sudah tercatat pada artefak atau percakapan sebelumnya. Skenario rework, actual cost dan cost overrun bertanggal simulasi 27 Januari 2027 pada dokumen budget tidak dimasukkan sebagai kejadian pada 21 Januari. Dokumen budget tidak diubah. Mitigasi, trigger dan kriteria gate di bawah adalah rencana kontrol, bukan catatan kejadian masa depan.

Sumber rinci dan pemetaan ke tiket tersedia pada sheet **Traceability** dan **RAID** di `11_RAID_Risk_Governance.xlsx`. Kode S01–S08 menunjuk RAID lama, audit data, evaluasi lama, inisiasi, governance, planning, basis estimasi budget, dan instruksi user.

## Register awal

| Jenis | ID | Jumlah | Dasar pencatatan |
|---|---|---:|---|
| Risk | R01–R03 | 3 | Leakage, salah interpretasi alert, dan salah representasi simulasi telah diidentifikasi sebelumnya. |
| Issue | I01–I04 | 4 | Temuan PV, gap reproduksi model lama, keunggulan model belum konklusif, dan pekerjaan AI yang pernah melampaui instruksi. |
| Assumption | A01–A04 | 4 | Ketersediaan fitur sebelum prediksi, kapasitas/kalender, reuse perangkat/lisensi, dan proxy estimasi biaya. |
| Dependency | D01–D02 | 2 | Ketersediaan Power BI untuk dashboard serta UAT/readiness sebelum penerimaan demo. |
| **Total** | | **13** | Tidak menambahkan insiden fiktif. |

UAT yang belum dilakukan belum jatuh tempo pada snapshot ini. Catatan lama tersebut diklasifikasi sebagai dependency D02, bukan issue keterlambatan. Power BI tetap ditunda dan tidak menghalangi jalur nonvisual. Status isu konteks I04 menyatakan koreksi sudah didokumentasikan; tidak mengarang persetujuan penutupan dari user.

## Penilaian risiko

Hanya Risk yang mendapat likelihood dan impact. Skala relatif 1–5 dan prioritas 1–7 Low, 8–14 Medium, 15–25 High adalah kebijakan simulasi, bukan ukuran probabilitas statistik atau standar universal.

| ID | Likelihood | Impact | Skor | Prioritas | Dasar dan batas |
|---|---:|---:|---:|---|---|
| R01 Leakage | 5 | 5 | 25 | High | Rating dari RAID lama; perlu review owner sebelum digunakan sebagai rating yang disahkan. |
| R02 Klaim alert | 4 | 4 | 16 | High | Rating lama, bukan probabilitas kejadian terukur. |
| R03 Representasi simulasi | 3 | 5 | 15 | High | Rating lama; belum ada persetujuan penerimaan risiko. |

Residual likelihood dan impact sengaja kosong. Formula menampilkan **Belum dinilai**, bukan nol. Rating residual baru boleh dicatat setelah ada bukti kontrol dijalankan dan hasil review. Label pada dokumen tidak otomatis membuktikan kontrol efektif.

## Rencana mitigasi

| Risiko | Pencegahan yang direncanakan | Trigger dan contingency | Bukti untuk review | Target |
|---|---|---|---|---|
| R01 | Tetapkan waktu prediksi, pisahkan outcome dari input, telaah fitur dan split per proyek. | Jika ditemukan fitur masa depan atau overlap proyek, tahan fitur/model terkait dan ajukan perbaikan data atau demonstrasi aturan yang valid. | Data dictionary as-of, daftar fitur, manifest split dan pipeline. | Sebelum G01; KAN-26/KAN-27. |
| R02 | Evaluasi alert pada kapasitas review yang sama; tampilkan precision, recall, jumlah alert dan batas klaim. | Jika klaim recall/probabilitas tidak disertai konteks beban atau kalibrasi, tahan klaim operasional; ranking eksploratif harus jelas batasnya. | Metrik threshold/top-k, pemeriksaan kalibrasi dan contoh review pengguna. | Sebelum G01/G03; KAN-28/KAN-32. |
| R03 | Labeli data dan narasi sebagai simulasi; bedakan peran nyata dan fiktif. | Jika narasi menyatakan deployment/manfaat/stakeholder nyata tanpa bukti, tahan bagian publikasi dan koreksi klaim. | Checklist klaim, sumber angka dan review narasi. | Sebelum G04; KAN-37/KAN-39. |

Owner simulasi: Data Owner untuk R01 dan PMO Lead untuk R02–R03. PIC aktual seluruh register adalah Naufal. Peran lain merupakan fungsi dalam skenario; tidak menugaskan atau menghubungi orang lain. Tindakan tidak diberi tanggal kejadian atau tanggal selesai rekaan; target dikaitkan dengan gate yang harus dipenuhi.

## Control gates

| Gate | Syarat penerimaan dan bukti | Status snapshot |
|---|---|---|
| G01 Kelayakan data/model | Waktu prediksi, fitur as-of, label, split, evaluasi dan keputusan penggunaan dapat ditelusuri. Bukti: dictionary, manifest, pipeline dan hasil evaluasi. | Belum dinilai; validasi model baru belum dilakukan. |
| G02 Security/akses | Hak penggunaan sumber jelas; pemeriksaan data sensitif dan credential tercatat. | Belum dinilai; belum ada security approval. |
| G03 Business UAT | Skenario input valid, prioritas tinggi dan kondisi gagal dijalankan; hasil aktual latihan pengguna, temuan, tindakan dan penerimaan dicatat. | Belum jatuh tempo; belum ada hasil UAT. |
| G04 Readiness/handover | Cara menjalankan batch, membaca hasil, menangani kegagalan dan menyerahkan file dapat diikuti; klaim portofolio sesuai bukti. | Belum jatuh tempo; Power BI yang ditunda harus disebutkan. |

Gate adalah kesiapan demonstrasi portofolio, bukan sertifikasi produksi perusahaan. Otoritas simulasi dijelaskan pada workbook; keputusan aktual tetap milik Naufal. Tidak ada gate yang dinyatakan lolos oleh penyusunan dokumen ini.

## Review, eskalasi dan perubahan

Mengikuti Governance Structure Tahap 1: check-in pada pengerjaan aktif dan review setiap akhir tahap. Review proyek mingguan, risiko dua mingguan dan steering bulanan merupakan cadence organisasi simulasi bila durasi skenarionya sesuai, bukan rapat yang diklaim sudah berlangsung.

Trigger yang sudah ditetapkan: forecast milestone mundur lebih dari satu hari kerja dilaporkan pada check-in berikutnya; kebutuhan layanan berbayar dilaporkan sebelum pengeluaran; outcome leakage atau baseline tidak valid menahan training/klaim; paparan credential/data sensitif menahan pemrosesan/publikasi terkait dan dilaporkan segera; kegagalan acceptance criteria diberi status perlu revisi atau ditahan. Ini adalah aturan respons, bukan kejadian yang dimasukkan ke RAID.

Perubahan scope, jadwal atau biaya dicatat dengan alasan dan dampak, diajukan sebagai opsi, lalu baseline hanya diperbarui setelah keputusan owner. Penugasan ini tidak mengubah baseline Tahap 1–3 dan tidak menjalankan mitigasi teknis Tahap 5.

## Cara melanjutkan register

1. Pertahankan versi snapshot awal ini. Tambahkan perubahan hanya jika ada dasar baru yang dapat dirujuk.
2. Pada versi berikutnya, catat tanggal pengamatan yang benar, bukti, owner, tindakan, target yang disepakati dan perubahan status; jangan mengisi histori mundur tanpa sumber.
3. Jika risk terjadi, buat Issue dengan ID baru dan tautkan ke Risk asal; pertahankan histori keduanya.
4. Tutup issue atau nilai ulang residual hanya setelah bukti penyelesaian/review tersedia.
5. Pisahkan RAID proyek, decision record, dan log pekerjaan AI. Log pekerjaan AI untuk penugasan ini tersedia pada `13_Log_Pekerjaan_Tahap_4.md`.

## Hasil pemeriksaan file

Workbook memuat lima sheet: Overview, RAID, Risk_Register, Control_Gates dan Traceability. Jumlah 13 catatan dan pembagiannya diperiksa. Formula skor diuji dengan perubahan input dan dikembalikan ke rating awal; formula residual diuji lalu dikembalikan kosong. Pemindaian formula tidak menemukan error Excel yang diperiksa. Tampilan kelima sheet serta bagian mitigasi dan catatan akhir RAID telah ditinjau.

Hasil ini menyelesaikan penyusunan Tahap 4. Penerimaan isi oleh owner, pelaksanaan kontrol, dan Tahap 5 tetap merupakan status terpisah.
