# Log pekerjaan kepada Naufal — Tahap 4

**Tanggal aktual: 3 November 2026**  
**Snapshot cerita proyek: 21 Januari 2027 — SIMULASI**  
Status penugasan: penyusunan dan pemeriksaan Tahap 4 selesai; review isi oleh owner belum dicatat.

Dokumen ini melaporkan pekerjaan AI dalam penugasan ini. Dokumen ini terpisah dari RAID proyek dan bukan timesheet, notulen rapat, atau persetujuan sponsor.

## Instruksi yang dilaksanakan

Menyelesaikan Tahap 4 menggunakan snapshot awal. Mengisi RAID dari catatan/temuan/asumsi sebelumnya saja. Tidak membuat histori kejadian mendatang; register akan dilengkapi seiring munculnya informasi baru.

## Yang diperiksa

- Panduan delapan tahap dan pemetaan WBS 4.1–4.3/T12–T14 ke KAN-23–KAN-25.
- Business Case, Charter, governance dan log inisiasi terbaru.
- Planning Master, backlog dan log Tahap 2 untuk kalender, kapasitas, dependency dan penundaan Power BI.
- Basis asumsi pada budget Tahap 3. Skenario rework/AC/overrun bertanggal simulasi 27 Januari 2027 tidak dibawa ke RAID 21 Januari.
- RAID dan audit/evaluasi lama untuk temuan yang sudah tercatat. Tidak menjalankan training atau evaluasi model baru.
- Deskripsi serta status tiga tiket Tahap 4 sebelum pembaruan dan hasilnya sesudah pembaruan.

## Yang dibuat

| File | Isi |
|---|---|
| `11_RAID_Risk_Governance.xlsx` | Lima sheet: Overview, RAID, Risk_Register, Control_Gates, Traceability. |
| `12_Mitigation_dan_Control_Plan.md` | Dasar snapshot, pemetaan 13 catatan, batas rating, mitigasi, trigger, contingency, control gates, eskalasi dan cara pembaruan. |
| `13_Log_Pekerjaan_Tahap_4.md` | Laporan pekerjaan ini kepada Naufal, terpisah dari RAID. |
| `raid_data.json` | Data isi register dan sumber sebagai pelengkap audit. |
| `verification.json` dan `verification_export.json` | Hasil pemeriksaan perhitungan dan file Excel hasil ekspor. |
| `jira_verification.json` | Hasil pembacaan ulang tiga tiket setelah perubahan. |

Paket ZIP Tahap 4 memuat seluruh file di atas. File hasil Tahap 1–3, dataset sumber dan panduan tidak diubah dalam penugasan ini.

## Keputusan penyusunan dan koreksi klasifikasi

1. Memuat 13 catatan: 3 Risk, 4 Issue, 4 Assumption, 2 Dependency. Tiap catatan memiliki dasar sumber, status, owner simulasi, PIC aktual, rencana tindak lanjut dan rujukan Jira.
2. Mempertahankan temuan lama sebagai informasi bawaan sebelum baseline baru. Tidak menyatakannya sebagai hasil Tahap 5 yang sudah selesai.
3. Mengklasifikasi UAT yang belum jatuh tempo sebagai dependency D02, bukan issue overdue. Power BI tetap dependency yang ditunda, bukan blocker jalur nonvisual.
4. Memakai skor inherent lama 25, 16, 15 sebagai rating sementara dengan batas yang jelas. Tidak memberi skor likelihood/impact kepada Issue, Assumption atau Dependency.
5. Mengosongkan input residual dan menampilkan **Belum dinilai** sampai ada bukti pengujian kontrol. Tidak mengklaim mitigasi efektif atau gate lolos.
6. Tidak mengarang tanggal pertama ditemukannya setiap catatan, tanggal selesai tindakan, rapat, persetujuan, pengeluaran atau jam aktual. Target mitigasi dinyatakan relatif terhadap gate pelaksanaan.
7. Menjelaskan perbedaan tanggal aktual penyusunan dan tanggal simulasi, serta mengecualikan kejadian finansial yang berada setelah snapshot awal.

## Pembaruan Jira yang berhasil

| Tiket | Hasil pembaruan | Status yang dibaca ulang |
|---|---|---|
| [KAN-23](https://naufalzulfikar.atlassian.net/browse/KAN-23) | Ringkasan master RAID, batas snapshot dan tautan workbook/rencana kontrol. | In Review |
| [KAN-24](https://naufalzulfikar.atlassian.net/browse/KAN-24) | Risk scoring, dasar rating, residual belum dinilai dan tautan bukti. | In Review |
| [KAN-25](https://naufalzulfikar.atlassian.net/browse/KAN-25) | Mitigation/gate plan, bukti yang diperlukan dan batas klaim. | In Review |

Tiga tiket dipindahkan dari To Do ke In Review. Kriteria penyusunan yang terpenuhi dicentang; kriteria gabungan bukti/review owner tetap belum dicentang karena review owner belum tercatat. Deskripsi awal dipertahankan sebagai konteks historis dengan catatan bahwa Tahap 4 kini diotorisasi. Tidak membuat tiket baru, menugaskan orang lain, atau mengubah tanggal baseline. Tautan bukti diperiksa dengan membaca ulang ketiga deskripsi.

## Pemeriksaan hasil

| Pemeriksaan | Hasil |
|---|---|
| Jumlah dan keunikan ID | 13 catatan; tidak ada ID ganda. |
| Pembagian jenis | Risk 3, Issue 4, Assumption 4, Dependency 2. |
| Skor inherent | 25, 16, 15 sesuai input. |
| Uji perubahan input skor | Mengubah likelihood sementara menghasilkan skor/prioritas yang sesuai; input dikembalikan. |
| Uji residual | Input sementara 2 × 3 menghasilkan 6; input dikosongkan kembali dan hasil menjadi Belum dinilai. |
| Error formula | Tidak ditemukan #REF!, #DIV/0!, #VALUE!, #NAME? atau #NUM! pada pemindaian. |
| Ekspor XLSX | Dibuka ulang; nilai cache, total, input residual kosong dan skor sesuai. |
| Traceability | Semua catatan memiliki sumber, owner/PIC dan referensi Jira. |
| Batas snapshot | Tidak ada kejadian 27 Januari pada baris master RAID; tidak ada gate dinyatakan lolos. |
| Tampilan | Lima sheet dan bagian mitigasi serta catatan akhir RAID ditinjau melalui hasil render. |
| Jira | KAN-23, KAN-24, KAN-25 terbaca In Review dan memiliki dua tautan bukti. |

## Status setelah penugasan

Tahap 4 selesai disusun dan diperiksa. Isi register serta rating sementara belum dinyatakan disetujui Naufal. Mitigasi dan gate baru berupa rencana yang akan diperiksa pada pelaksanaan sesuai otorisasi berikutnya. Tahap 5 belum dimulai dalam penugasan ini; Power BI tetap ditunda. Tidak ada model baru, kode XGBoost, UAT, deployment, publikasi portofolio atau pembelian yang dikerjakan.
