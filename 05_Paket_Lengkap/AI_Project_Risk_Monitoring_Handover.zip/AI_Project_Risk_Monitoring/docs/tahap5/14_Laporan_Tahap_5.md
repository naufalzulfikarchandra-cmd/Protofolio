# Tahap 5 — Data dan Risk Prediction Engine

**AI Project Risk Monitoring — Independent Simulation Project**  
Tanggal pengerjaan aktual: **4 November 2026**. Pelaksana eksekusi: **AI di workspace CPU**.  
Status: **deliverable dan benchmark eksploratif selesai untuk review; G01 operasional HOLD**.

## Keputusan utama

Model terpilih berdasarkan validation adalah **RF_depth4**, bukan berdasarkan test. Pada test sintetis 277 proyek (188 terlambat), top-56 model menangkap **44** proyek terlambat; aturan CPI menangkap **39**. Selisih recall pada kapasitas 20% sebesar **2.66 poin persentase**, dengan interval bootstrap deskriptif 95% **-2.05 sampai 7.49 poin**. Interval mencakup nol: keunggulan belum konklusif.

Kualitas prediksi operasional belum dapat diterima. Data adalah simulasi berbasis aturan; timestamp pencatatan EV/AC, baseline budget yang frozen dan kode generator belum tersedia. Mengeluarkan outcome eksplisit tidak membuktikan semua mekanisme pembangkitan fitur bebas dari informasi masa depan. Model disimpan hanya untuk reproduksi benchmark, bukan direkomendasikan untuk keputusan perusahaan nyata.

## Kesesuaian dengan proyek

Tahap 5 memuat T15/KAN-26 (audit/dictionary), T16/KAN-27 (snapshot/split) dan T17/KAN-28 (model/evaluasi). Baseline cerita proyek tetap 22 Januari–1 Februari 2027: ini rencana simulasi dari Tahap 2, bukan actual pelaksanaan pada tanggal tersebut. Tidak mengubah jadwal, budget, atau snapshot RAID awal untuk membuatnya seolah sudah terealisasi.

Keputusan user: monitoring saat proyek sedang berjalan; sumber Mendeley DOI 10.17632/2p5sz57wh2.1; skenario kapasitas belum ditentukan. Pilihan akhir bulan 2 dan kapasitas 10/20/30% merupakan **asumsi eksperimen yang terlihat**, bukan persetujuan kapasitas tim. Populasi IT mengikuti fokus proyek terdahulu; sektor lain tidak diklaim tercakup.

## Sumber dan hasil audit

Reyhane Hajihoseyni, Mendeley Data v1, terbit 15 Februari 2026. Halaman sumber menyebut data sintetis berbasis aturan dan CC BY 4.0. URL dan atribusi lengkap di `SOURCE_AND_LICENSE.md`. File digunakan dari lampiran user; belum dibandingkan byte demi byte dengan unduhan baru Mendeley. SHA-256 lampiran ada pada `results/environment.json`.

| Pemeriksaan | Hasil |
|---|---|
| Proyek raw / summary | 4.000 / 4.000 |
| Pengamatan proyek-bulan | 72.549 |
| ID raw/summary unik; ID bulanan gabungan unik | Lulus |
| Himpunan ID ketiga file sama | Lulus |
| Label delay = durasi aktual − rencana | Lulus |
| Rekonsiliasi budget/durasi lintas file dan cost overrun | Lulus |
| Format dua XLSX | CSV satu kolom dalam workbook; didekode tanpa mengubah sumber |
| PV pada akhir durasi rencana untuk proyek terlambat | 2.448 dari 2.448 masih di bawah budget; tidak layak diperlakukan sebagai baseline frozen |
| SPI bulanan | 276 nilai berbeda dari rasio increment mentah; cocok dengan clipping 0,6–1,4; tidak dipakai |
| CPI kumulatif | Cocok dengan EV/AC; tetap belum membuktikan ketersediaan as-of |
| Literal `None` | Dipertahankan: Change_Control_Maturity 780, Risk_Management_Maturity 791; jangan otomatis dibaca missing |
| Literal `N/A` | Tech_Environment_Stability 2.619; makna tidak berlaku/tidak tersedia belum jelas; tidak diimputasi atau digunakan |
| Empty string pada parser preservasi | 0; tidak berarti semua semantik data lengkap |

Angka temuan berasal dari audit baru, bukan sekadar menyalin laporan lama. Deteksi baseline PV tidak membuktikan penyebab di kode generator karena kode itu tidak tersedia. Tidak mengganti PV dengan kurva buatan untuk menyembunyikan gap. Semua deskriptor risiko statis yang waktu pembaruannya tidak jelas dikeluarkan.

## Snapshot, target dan batas fitur

Grain dataset model: **satu proyek pada akhir bulan 2**. Eligibility: sektor IT, durasi rencana lebih dari 2 bulan, tersedia pengamatan bulan 1/2, dan EV bulan 2 masih di bawah budget. Kriteria memakai informasi snapshot, tidak memakai outcome untuk memilih proyek. Sebanyak **1.381** memenuhi syarat, tidak ada proyek IT yang dikeluarkan; **936** akhirnya terlambat.

Target `delayed = 1` jika `Schedule_Delay > 0`. Label memakai bulan, tidak mengarang tanggal selesai kalender atau ambang keterlambatan hari. Sumber tidak menyediakan tahun/waktu pencatatan yang memadai untuk temporal backtest; pengujian adalah project holdout internal, bukan validasi lintas waktu.

| Fitur | Perhitungan |
|---|---|
| `planned_months` | Estimated_Timeline_Months |
| `log_budget` | log1p(Project_Budget_USD) |
| `earned_fraction_m2` | EV bulan 2 / budget |
| `spent_fraction_m2` | AC bulan 2 / budget |
| `cpi_m2` | EV bulan 2 / AC bulan 2 |
| `earned_delta_fraction` | (EV2 - EV1) / budget |
| `spent_delta_fraction` | (AC2 - AC1) / budget |

Hanya data bulan 1–2 dipakai untuk menghitung fitur. Budget dan durasi diperlakukan sebagai parameter rencana provisional. EV/AC merupakan pengukuran sintetis provisional; tanpa bukti as-of, hasil ini tetap bersyarat. Proyek berumur lain, seluruh horizon bulanan dan input operasional baru belum diuji. Budget USD pada sumber tidak digabung dengan budget IDR pembangunan solusi Tahap 3.

Dilarang sebagai input: Project_ID, Risk_Level sumber, Actual_Duration_Months, Actual_Cost akhir, Schedule_Delay, Cost_Overrun, semua observasi setelah bulan 2, PV/SPI/SV serta risiko statis yang belum dapat dipastikan waktunya. ID hanya untuk join, split, pelacakan dan tie-break yang deterministik.

## Protokol model

Split stratified berdasarkan ID: **828 train, 276 validation, 277 test**, seed 20261104. Tidak ada proyek lintas split. Normalisasi/imputasi hanya fit di dalam train dan fold calibration. Empat kandidat: Logistic Regression C=0,1/1 dan Random Forest max_depth=4/8 (200 trees, min_samples_leaf=10). Sigmoid calibration memakai CV stratified 3 fold di dalam train saja. Tidak memakai XGBoost.

Model dipilih berdasarkan validation average precision (AP); threshold diagnostik 0,5 dan kapasitas ilustratif 20% ditetapkan sebelum scoring test. Tidak melakukan tuning pada test atau refit setelah melihat test. Model tersimpan tetap merupakan hasil fit train. Skor lama dari HTML tidak digunakan. Data pernah diperiksa pada pekerjaan lama; split ini bukan bukti holdout eksternal yang belum pernah disentuh dalam seluruh riwayat proyek.

| Kandidat pada validation | AP | Brier |
|---|---:|---:|
| LR_C0.1 | 0.7607 | 0.2067 |
| LR_C1 | 0.7553 | 0.2085 |
| RF_depth4 | 0.7835 | 0.2056 |
| RF_depth8 | 0.7830 | 0.2062 |
| CPI_rule | 0.6848 | — |

Aturan pembanding adalah ranking CPI bulan 2 yang lebih rendah lebih dahulu; alert diagnostik jika CPI < 1. Ini indikator biaya sederhana, bukan aturan SPI yang dipaksakan memakai PV tidak valid. Skor aturan tidak diperlakukan sebagai probabilitas. Pembanding tambahan menggunakan prevalensi train (skor konstan).

## Evaluasi test

AP dan ROC-AUC lebih tinggi lebih baik; Brier lebih rendah lebih baik. Prevalensi keterlambatan test **67,87%** membuat AP tinggi harus dibaca dibanding baseline.

| Metode | AP | ROC-AUC | Brier |
|---|---:|---:|---:|
| RF_depth4 | 0.7530 | 0.5961 | 0.2138 |
| CPI_rule | 0.6805 | 0.4989 | Tidak berlaku |
| Train_prevalence | 0.6787 | 0.5000 | 0.2181 |

Threshold 0,5 pada model menandai **253 dari 277** proyek: precision **69,17%**, recall **93,09%**, F1 **79,37%**. Confusion matrix TN=11, FP=78, FN=13, TP=175. Recall tersebut menuntut review hampir seluruh proyek. Pembanding yang menandai semua proyek bahkan mencapai F1 **80,86%**; karena itu F1/recall saja tidak membuktikan kegunaan PMO.

Pada aturan CPI < 1, alert 179, precision 67,60%, recall 64,36%. Perbandingan threshold ini berbeda beban dan **tidak** dijadikan bukti menang pada kapasitas setara. Gunakan tabel berikut untuk perbandingan kapasitas setara; k dibulatkan ke atas, tie dipecahkan berdasarkan ID, bukan outcome.

| Metode | Kapasitas ilustratif | k | Terlambat tertangkap | Precision@k | Recall@k |
|---|---:|---:|---:|---:|---:|
| RF_depth4 | 10% | 28 | 21 | 75.0% | 11.2% |
| CPI_rule | 10% | 28 | 19 | 67.9% | 10.1% |
| RF_depth4 | 20% | 56 | 44 | 78.6% | 23.4% |
| CPI_rule | 20% | 56 | 39 | 69.6% | 20.7% |
| RF_depth4 | 30% | 84 | 64 | 76.2% | 34.0% |
| CPI_rule | 30% | 84 | 61 | 72.6% | 32.4% |

Pada top-56, model menghasilkan 12 false alert dan masih melewatkan 144 dari 188 kasus terlambat; aturan menghasilkan 17 false alert dan melewatkan 149. Pengurangan beban review mempunyai trade-off kasus terlewat. Belum ada kapasitas atau toleransi bisnis yang disetujui user. Bootstrap 2.000 kali memakai sampel proyek berpasangan untuk kedua metode; interval tidak memperbaiki masalah data sintetis/as-of dan bukan jaminan generalisasi.

Calibration sigmoid telah dihitung, tetapi tidak otomatis menjadikan skor probabilitas operasional yang valid. Brier model **0.2138** versus skor prevalensi **0.2181**; perbaikan kecil pada satu test sintetis. Pemeriksaan bin quantile deskriptif:

| Rata-rata skor model | Proporsi terlambat teramati |
|---|---:|
| 0.508 | 0.554 |
| 0.664 | 0.673 |
| 0.719 | 0.636 |
| 0.737 | 0.745 |
| 0.756 | 0.786 |

## Keputusan gate dan tindak lanjut

**G01 HOLD untuk penerimaan operasional.** Benchmark dapat diperiksa dan direproduksi, tetapi belum mendukung klaim prediksi terlambat yang tervalidasi di perusahaan nyata. Langkah berikut untuk mengubah keputusan: bukti definisi dan snapshot as-of EV/AC, baseline rencana frozen, penjelasan generator, atau dataset lain yang memenuhi syarat; kemudian evaluasi ulang dan kesepakatan kapasitas/toleransi bisnis. Tidak mengganti sumber atau merekayasa data tanpa keputusan owner.

Rujukan RAID awal: I01 (PV), A01 (as-of), R01 (leakage), R02 (beban alert), I02 (reproduksi), I03 (keunggulan belum konklusif). Artefak baru mengatasi ketiadaan pipeline **eksperimen baru**, tetapi tidak memulihkan atau mereproduksi training lama. Tidak menutup isu lama atau menurunkan residual risk otomatis. Snapshot RAID Tahap 4 tetap utuh; observasi baru ini tercatat sebagai hasil audit aktual, bukan insiden masa depan yang dikarang.

## Bukti pengujian dan batas tahap

Kunci/rekonsiliasi sumber, ID disjoint, fitur finite dan reload model diuji. Uji perubahan semua data setelah bulan 2, kolom final dan PV tidak mengubah fitur snapshot. Ini membuktikan batas kode, bukan membuktikan generator tidak memakai outcome. File model menyimpan preprocessing dan calibration lengkap; versi lingkungan dan hash sumber/script/protokol dicatat.

Notebook dan petunjuk Windows tersedia. Ketujuh sel kode notebook telah dieksekusi berurutan melalui Python dengan namespace bersama; hasil prediksi dari training ulang cocok dengan benchmark. Sumber dengan ID proyek ganda atau label tidak konsisten ditolak pada pemeriksaan negatif. Eksekusi native Jupyter tidak tersedia di lingkungan ini dan tidak diklaim telah diuji. Bukti ada di `results/notebook_verification.json`. Naufal belum dinyatakan melakukan training sendiri. Tidak menjalankan batch operasional, UAT, dashboard, deployment atau Tahap 6. Tidak mengklaim sign-off security maupun business.
