# Log pekerjaan kepada Naufal — Tahap 5

**Tanggal aktual: 4 November 2026.** Proyek: AI Project Risk Monitoring — Independent Simulation Project. Pelaksana training/checks: AI pada CPU workspace. Ini laporan pekerjaan AI, terpisah dari RAID proyek.

## Otorisasi dan hasil

User mengotorisasi Tahap 5 setelah memilih prediksi saat proyek berjalan dan memberikan sumber Mendeley. Kapasitas review belum ditentukan. Audit, dataset model, eksperimen, notebook, evaluasi dan dokumentasi selesai disusun. **Penerimaan operasional G01 tetap HOLD**, bukan status model siap dipakai di perusahaan nyata.

Tidak menganggap tanggal baseline simulasi 22 Januari–1 Februari 2027 sebagai tanggal actual. Tidak mengarang jam kerja Naufal, rapat, keputusan sponsor atau persetujuan owner. Penetapan snapshot bulan 2 serta kapasitas 10/20/30% merupakan asumsi benchmark, bukan persetujuan bisnis.

## Yang diperiksa

- Charter, ruang lingkup delapan tahap, planning/WBS, hasil audit lama dan snapshot RAID awal.
- Halaman Mendeley v1: judul, penulis, DOI, sifat sintetis, deskripsi tiga file dan lisensi. Identitas byte terhadap unduhan repository baru belum diverifikasi; memakai lampiran yang sudah tersedia dan mencatat hash.
- Tiga sumber asli: 4.000 proyek raw, 4.000 summary, 72.549 proyek-bulan. Dua workbook didekode dari CSV satu kolom tanpa mengubah sumber.
- Kunci dan join, label delay, biaya, budget, durasi, indikator EV, kategori literal None/N/A, eligibility, as-of dan potensi outcome leakage.

## Yang dibuat dan dijalankan

| Bagian | Hasil |
|---|---|
| T15/KAN-26 | Audit baru dan dictionary 80 baris kolom sumber/fitur; sumber, formula, tipe, peran dan batas waktu. |
| T16/KAN-27 | Snapshot akhir bulan 2 untuk 1.381 proyek IT; 7 fitur; manifest ID 828/276/277 train/validation/test. |
| T17/KAN-28 | Empat kandidat LR/RF dengan calibration train-only; pemilihan validation AP; evaluasi test dan skenario kapasitas setara. |
| Model tersimpan | Pipeline preprocessing/calibration lengkap, bukan file skor saja; model card dan versi dependensi. |
| Notebook | Tujuh sel kode diuji berurutan melalui Python; output nyata ditangkap; dapat digunakan untuk latihan reproduksi. |
| Dokumentasi | Laporan hasil, README Windows, protokol, persyaratan library, atribusi/lisensi dan log ini. |

Tidak menggunakan XGBoost. Tidak mengambil skor model dari dashboard HTML lama. Tidak memperbaiki atau menciptakan PV/EV/AC baru untuk membuat hasil terlihat bagus. PV/SPI/SV, outcome eksplisit, serta fitur risiko statis tanpa timestamp dikeluarkan dari benchmark. EV/AC bulan 1–2 dan parameter rencana tetap berstatus asumsi as-of sintetis; model tidak disertifikasi bebas semantic leakage.

## Hasil dan keputusan

RF_depth4 dipilih berdasarkan AP validation 0,7835. Test mempunyai 277 proyek, 188 terlambat. Test AP 0,7530, ROC-AUC 0,5961 dan Brier 0,2138. Pada kapasitas ilustratif 56 review, model menangkap 44 kasus terlambat, aturan CPI 39. Interval bootstrap 95% selisih recall −2,05 hingga 7,49 poin persentase mencakup nol; keunggulan belum konklusif.

Recall 93,09% pada threshold 0,5 memerlukan 253 alert dari 277, sehingga tidak dijadikan klaim review efisien. Baseline selalu-alert bahkan mempunyai F1 lebih tinggi daripada model pada threshold ini. Laporan menjelaskan trade-off beban review dan kasus terlewat.

Gate operasional ditahan karena baseline/as-of dan generator belum dapat dibuktikan, sumber hanya sintetis, serta kapasitas/toleransi bisnis belum ditentukan. Ini hasil review kelayakan yang harus terlihat, bukan error yang diubah menjadi lolos. Uji algoritma pada benchmark tetap dapat direproduksi. Tidak mengganti dataset atau membuat skenario perusahaan baru tanpa keputusan user.

## Pemeriksaan yang dilakukan

- Assert kunci unik, ID konsisten lintas sumber, label serta rekonsiliasi cost/budget/durasi.
- Split per proyek tanpa ID tumpang tindih; satu snapshot per proyek dan fitur finite.
- Uji perubahan data setelah bulan 2 serta kolom PV/hasil akhir: fitur tetap sama.
- Muat ulang model tersimpan: hasil prediksi sama.
- Jalankan ulang kode notebook dari awal pada namespace bersama: tujuh sel lulus; skor test sama dengan benchmark.
- Uji negatif: ID proyek ganda serta label tidak konsisten ditolak audit.
- Verifikasi independen metrik dan manifest pada hasil ekspor, serta integritas paket ZIP.

Tidak ada Jupyter kernel/nbclient di lingkungan ini. Pengujian adalah eksekusi kode notebook melalui Python, bukan pengujian native antarmuka Jupyter, Colab atau Windows. Naufal belum dicatat menjalankan notebook sendiri. Versi Python/library serta hash sumber, protokol dan script disertakan agar hasil dapat diperiksa.

## Jira

Tiga tiket yang sudah ada diperbarui deskripsinya, diberi tautan laporan/notebook, dan dipindahkan ke **In Review**:

- [KAN-26 — Audit dan dictionary](https://naufalzulfikar.atlassian.net/browse/KAN-26)
- [KAN-27 — Snapshot dan split](https://naufalzulfikar.atlassian.net/browse/KAN-27)
- [KAN-28 — Model dan evaluasi](https://naufalzulfikar.atlassian.net/browse/KAN-28)

Respons transisi mengonfirmasi status In Review untuk ketiganya. Acceptance criteria awal tidak dinyatakan disetujui owner. Kesenjangan semantic as-of dan HOLD ditulis pada semua tiket. Tidak membuat tiket baru, menugaskan orang lain, atau mengubah tanggal baseline. Rincian ringkas: `results/jira_verification.json`.

## Status dokumen sebelumnya dan batas pekerjaan

Dokumen Tahap 1–4 dan snapshot RAID awal tidak diubah. Audit baru merujuk I01, A01, R01, R02, I02 dan I03 sebagai tindak lanjut, tanpa mengklaim isu lama ditutup atau residual risk turun. Artefak training baru tidak memulihkan artefak training lama yang hilang.

Tahap 6, batch operasional proyek baru, Power BI, UAT, security sign-off, deployment, publikasi dan pembelian belum dilaksanakan. `test_predictions.csv` hanya hasil holdout sintetis. Untuk latihan sendiri, ekstrak paket lengkap dan ikuti README; hasil latihan masuk `my_run/`.
