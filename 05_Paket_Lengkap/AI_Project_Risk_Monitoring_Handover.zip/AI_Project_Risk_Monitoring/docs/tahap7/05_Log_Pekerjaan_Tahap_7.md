# Log pekerjaan Tahap 7

AI Project Risk Monitoring · PMO Risk Dashboard · 6 November 2026

Laporan ini ditujukan kepada Naufal untuk menjelaskan pekerjaan AI. Ini terpisah dari RAID, decision register, timesheet dan bukti penerimaan bisnis.

## Otorisasi dan batas

Instruksi aktif adalah mengerjakan Tahap 7 Pelaporan dan Keputusan. Arah Opsi B dijelaskan sebagai pemeriksaan kelayakan data sebelum mempertimbangkan training ulang. Tahap 7 menyusun bahan keputusan dan rencana pemeriksaan. Tidak ada penugasan audit data tambahan, penggantian dataset, retraining, deployment atau Tahap 8 yang dijalankan.

## Hasil yang dibuat

| Hasil | Isi | Bukti pemeriksaan |
|---|---|---|
| 01 Laporan Status Proyek | 3 halaman, status 8 tahap, RAG, metrik kapasitas 20%, snapshot biaya, blocker dan tindak lanjut | Render 3 halaman dan review tampilan |
| 02 Brief Keputusan Opsi B | 3 halaman, perbandingan dua opsi, rencana 8 jam, perhitungan biaya, aturan retraining dan gate | Render 3 halaman, hitungan usaha dan biaya diperiksa |
| 03 Lessons Learned | 3 halaman dan register 8 pelajaran dengan bukti serta trigger penerapan | Render 3 halaman dan konsistensi register |
| 04 Presentasi Steering | 8 slide dengan tabel editable dan catatan sumber | Delapan preview diperiksa, validasi struktur dan import lulus |
| Decision register | 5 catatan, membedakan arahan user, kontrol berlaku dan usulan | Status persetujuan tidak diisi fiktif |
| Sumber dan verifikasi | 18 rujukan, salinan bukti terpilih, hash dan ringkasan angka | Hash sumber dan salinan cocok |

## Pemeriksaan yang benar benar dilakukan

Membaca ulang baseline, laporan budget, audit dan evaluasi model, bukti HTML, hasil notebook serta status Jira. Memeriksa metadata sumber Mendeley v1 dan referensi PMI mengenai penerapan lessons learned. Tidak mengunduh dataset baru atau menyamakan pemeriksaan halaman metadata dengan audit generator.

Menghitung ulang ranking dari test_predictions.csv: 277 proyek dan 188 label terlambat. Pada top 56, RF menangkap 44 dan aturan CPI menangkap 39. Selisih recall 5/188 adalah 2,66 poin persentase. Interval bootstrap yang sudah tersedia mencakup nol. Tidak menjalankan training untuk menghasilkan angka ini.

Memeriksa angka EAC = AC + ETC dan overrun terhadap BAC, lalu mempertahankan cutoff SIM 27 Januari 2027. Usulan Opsi B 6 jam Data × Rp66.697,50 + 2 jam PMO × Rp325.237,50 = Rp1.050.660 bruto. Jam dan tarif memakai asumsi serta snapshot lama yang dinyatakan. Tidak menambahkan jumlah bruto tersebut langsung ke EAC karena bisa tumpang tindih dengan rework Base.

Memeriksa tampilan 9 halaman DOCX dan 8 slide. Memperbaiki garis bawaan judul, format nilai negatif, font presentasi dan teks yang terlalu panjang sebelum menghasilkan berkas final. Validasi PPTX final mencatat 8 slide, 4 tabel native, tanpa temuan struktur atau geometri dan import berhasil. Pemeriksa arithmetic otomatis melewati tabel tanpa jumlah sederhana atau angka berformat IDR; perhitungan metrik dan biaya diperiksa terpisah. Native Microsoft Word dan PowerPoint Windows tidak dibuka, sehingga tidak diklaim teruji di aplikasi tersebut.

## Perubahan Jira

KAN-33, KAN-34 dan KAN-35 diperbarui dengan isi hasil, acceptance checklist, baseline simulasi yang dipertahankan dan tautan bukti. Ketiganya berpindah dari To Do ke In Review. Checkbox penerimaan owner tetap kosong, assignee tidak diubah dan tidak ada worklog jam aktual yang dibuat. Bukti state yang dikembalikan Jira disimpan pada evidence/jira_verification.json.

Tiket Tahap 8 KAN-36 sampai KAN-39 tidak diubah. Snapshot sebelumnya dan pemeriksaan batas tahap disertakan. Status In Review bukan tanda sign off owner dan bukan alasan mengklaim seluruh proyek selesai.

## Status akhir dan hal yang masih terbuka

Keluaran Tahap 7 selesai disusun dan diperiksa untuk review owner. Status keseluruhan KUNING, kesiapan operasional model MERAH dengan G01 HOLD. G02 belum disetujui, G03 belum diterima dan G04 menunggu review owner. Tidak ada keputusan sponsor fiktif.

Dashboard HTML Tahap 6 tetap artefak snapshot, bukan koneksi Jira live. Data delivery di HTML lama belum memuat perubahan status tiga tiket Tahap 7 ini. Status terbaru untuk Tahap 7 ada pada Jira dan bukti paket ini. Tidak mengubah dashboard atau baseline lama secara diam diam.

Tanggal dokumen aktual 6 November 2026, posisi cerita SIM akhir Tahap 7 adalah 9 Februari 2027, dan keuangan tetap snapshot 27 Januari 2027. Usulan audit Opsi B belum dikerjakan. Dampak bersih biaya dan jadwal perubahan HTML maupun Opsi B masih perlu rekonsiliasi. Tindak lanjut peran dan trigger tersedia dalam brief; penerapan lessons learned belum diukur.

## Isi paket

Paket Tahap 7 berisi dokumen final, presentasi, dua register CSV, log ini, ringkasan angka, source register, bukti yang dirujuk dan manifest hash. Sumber authoring ikut disimpan untuk jejak pembuatan, dengan konteks build asli dijelaskan pada README sumber. Paket ini khusus pelaporan Tahap 7, belum menjadi paket handover final Tahap 8.
