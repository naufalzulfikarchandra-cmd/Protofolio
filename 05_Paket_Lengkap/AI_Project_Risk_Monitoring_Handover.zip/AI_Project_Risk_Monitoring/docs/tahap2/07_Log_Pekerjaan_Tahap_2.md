# Log pekerjaan Tahap 2

Tanggal pelaksanaan: 3 November 2026. Proyek dummy AI Project Risk Monitoring.

## Mandat
Menyelesaikan planning dan scheduling serta mengisi Jira. Pelaksanaan tahap model dan visualisasi belum diotorisasi dalam penugasan ini. Windows adalah perangkat user; Power BI ditunda karena tidak tersambung.

## Hasil
- Workbook Excel berisi Overview dan milestone, WBS dictionary, Master Schedule, dan RACI.
- Jira project KAN dipilih karena merupakan project pribadi noncontoh yang tersedia. Project SAM1 bernama Example tidak dipakai.
- Dibuat 8 Epic KAN-4 sampai KAN-11 dan 28 task KAN-12 sampai KAN-39.
- Dipasang 26 link Blocks yang diverifikasi melalui baca ulang Jira.
- Setiap task memiliki referensi WBS, keluaran, acceptance criteria, estimasi usaha dan peran simulasi. Estimasi usaha dicatat pada deskripsi; tidak mengklaim native time tracking telah dikonfigurasi.
- Start date dan due date terpasang sebagai field Jira untuk 27 task terjadwal dan 8 Epic. Task T20 ditunda tanpa tanggal.
- Tiga tiket awal KAN-1 sampai KAN-3 tidak diubah.

## Asumsi baseline
Kalender simulasi dimulai Senin 4 Januari 2027 dan berakhir Senin 15 Februari 2027: 31 hari kerja aktif dan 93 jam, 3 jam/hari. Kalender Senin-Jumat tanpa pengecualian libur nasional; bukan tanggal realisasi. Tidak ada janji bahwa pengerjaan pribadi membutuhkan 31 hari. Asumsi empat hari plus satu cadangan pada inisiasi bukan baseline simulasi ini. Satu pelaksana aktual memerankan tim fiktif, sehingga baseline dibuat berurutan. Sebagian dependency merupakan urutan kapasitas dan persetujuan deliverable, bukan ketergantungan teknis mutlak. Baseline belum memasukkan contingency tambahan; kelayakan data yang gagal memerlukan keputusan revisi.

T20 Power BI tidak memiliki tanggal atau link blocking dan tidak menghambat T21 QA nonvisual. Predecessor T20 di workbook hanyalah syarat jika kelak diaktifkan. Penyelesaian tahap 6 saat visualisasi ditunda hanya mencakup batch dan QA nonvisual; dashboard penuh tidak diklaim selesai. Tahap publikasi wajib menyebut pengecualian visual ini.

## Status dan workflow
Board KAN sudah menyediakan Idea, To Do, In Progress, In Review dan Done; tidak dibuat board atau workflow baru. Delapan task Tahap 1 dan 2 berada pada In Review karena hasil tersedia atau diserahkan dalam penugasan ini, bukan karena owner telah menyetujui. Sembilan belas task lain To Do. T20 berada pada Idea dengan label deferred-powerbi. Delapan Epic tetap Idea sebagai pengelompokan backlog; status anak tidak otomatis meroll-up. Tidak ada tiket yang ditandai Done. Jangan memakai status category Jira untuk menyimpulkan progress: konfigurasi project ini menempatkan To Do pada kategori indeterminate.

Actual Start, Actual Finish, Progress dan Forecast Finish pada workbook dibiarkan kosong. Tidak ada waktu realisasi, persetujuan atau anggota tim yang dikarang. Jira assignee kosong; pemilik peran dijelaskan dalam deskripsi, tanpa menugaskan orang lain.

## Pemeriksaan
Baca ulang Jira menemukan tepat 36 work item berlabel maganghub-risk-pmo. Parent Epic, field start/due dan predecessor native pada task sesuai manifest. Tidak ditemukan mismatch. Workbook menghitung 93 jam dari durasi kali kapasitas, RACI mempunyai tepat satu A dan setidaknya satu R per aktivitas. Error formula scan tidak menemukan kesalahan. Tampilan setiap worksheet diperiksa. Pengujian langsung melalui aplikasi Excel Windows belum dilakukan; file XLSX tersedia untuk dibuka di perangkat user. Jadwal ini adalah baseline statis: mengubah durasi tidak otomatis menggeser seluruh tanggal baseline atau menyinkronkan Jira. Jika rencana berubah, lakukan change control dan perbarui keduanya secara eksplisit.

## Tidak dikerjakan
Tidak melakukan training, memilih algoritma final, mengolah ulang dataset, membuat budget actual, RAID terperinci, PBIX, dashboard visual, atau menjalankan tahap 3-8. Backlog tahap tersebut dibuat sebagai perencanaan saja. Tidak membuat Confluence page karena sumbernya dokumen Tahap 1, bukan halaman Confluence. Tidak mempublikasikan repository atau mengirim pesan ke stakeholder.

## Cara memakai
Buka board https://naufalzulfikar.atlassian.net/jira/software/projects/KAN/boards/1 dan filter label maganghub-risk-pmo. Tiket tahap 2 adalah KAN-16, KAN-17, KAN-18 dan KAN-19. Kolom In Review berisi pekerjaan menunggu peninjauan, bukan backlog yang perlu dilatih ulang. Workbook dan daftar CSV menyertakan key serta URL untuk pencocokan.

## Pemetaan Jira

| Task | WBS | Epic | Jira | Deliverable |
|---|---|---|---|---|
| T01 | 1.1 | KAN-4 | KAN-12 | Business case |
| T02 | 1.2 | KAN-4 | KAN-13 | Project charter |
| T03 | 1.3 | KAN-4 | KAN-14 | Register stakeholder |
| T04 | 1.4 | KAN-4 | KAN-15 | Governance dan komunikasi |
| T05 | 2.1 | KAN-5 | KAN-16 | WBS dictionary |
| T06 | 2.2 | KAN-5 | KAN-17 | Schedule baseline |
| T07 | 2.3 | KAN-5 | KAN-18 | RACI |
| T08 | 2.4 | KAN-5 | KAN-19 | Backlog Jira |
| T09 | 3.1 | KAN-6 | KAN-20 | Cost baseline |
| T10 | 3.2 | KAN-6 | KAN-21 | Cost tracker |
| T11 | 3.3 | KAN-6 | KAN-22 | KPI dictionary |
| T12 | 4.1 | KAN-7 | KAN-23 | RAID master |
| T13 | 4.2 | KAN-7 | KAN-24 | Risk register |
| T14 | 4.3 | KAN-7 | KAN-25 | Mitigation dan gate plan |
| T15 | 5.1 | KAN-8 | KAN-26 | Data dictionary dan audit |
| T16 | 5.2 | KAN-8 | KAN-27 | Dataset dan split manifest |
| T17 | 5.3 | KAN-8 | KAN-28 | Pipeline dan evaluation report |
| T18 | 6.1 | KAN-9 | KAN-29 | Kontrak input output batch |
| T19 | 6.2 | KAN-9 | KAN-30 | Data contract dan KPI measures |
| T20 | 6.3 | KAN-9 | KAN-31 | Dashboard Power BI |
| T21 | 6.4 | KAN-9 | KAN-32 | Integration test evidence |
| T22 | 7.1 | KAN-10 | KAN-33 | Status report simulasi |
| T23 | 7.2 | KAN-10 | KAN-34 | Decision brief |
| T24 | 7.3 | KAN-10 | KAN-35 | Lessons learned |
| T25 | 8.1 | KAN-11 | KAN-36 | Handover package |
| T26 | 8.2 | KAN-11 | KAN-37 | Portfolio case study |
| T27 | 8.3 | KAN-11 | KAN-38 | Repository plan |
| T28 | 8.4 | KAN-11 | KAN-39 | CV dan demo narrative |

Status akhir: Tahap 2 selesai disusun dan Jira terisi; penerimaan owner belum dicatat. Penugasan berhenti pada Tahap 2.

