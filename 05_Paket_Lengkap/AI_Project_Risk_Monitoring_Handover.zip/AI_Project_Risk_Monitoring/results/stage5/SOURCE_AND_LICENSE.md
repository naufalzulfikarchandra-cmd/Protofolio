# Source attribution and provenance

Reyhane Hajihoseyni (2026), *Simulated project risk and earned-value dataset: project features, monthly PV/EV/AC time series and delay/cost outcomes*, Mendeley Data, Version 1, DOI **10.17632/2p5sz57wh2.1**.

Source: https://data.mendeley.com/datasets/2p5sz57wh2/1 (page accessed 4 November 2026).

The page identifies this as synthetic data, generated through a rule-based simulation, and states **CC BY 4.0**. License reference: https://creativecommons.org/licenses/by/4.0/ . Credit must accompany redistributed derivatives. No endorsement by the contributor is implied.

`source/` contains the three files previously supplied by the user, copied without byte changes. Filenames match the source description; no independent download/checksum comparison with the repository files was performed. Thus the URL is the user-supplied provenance, not proof of byte identity to a freshly downloaded repository version. Local SHA-256 hashes are in `results/environment.json`.

Changes in this package: decoded one-column CSV-in-XLSX representations; joined project IDs; selected IT projects at month 2; derived seven numerical features; created a split manifest, predictions and metrics. Original files are preserved. No repair or regeneration of PV/EV/AC trajectories was performed.

Documentation of methods consulted:
- https://scikit-learn.org/stable/common_pitfalls.html — leakage, train-only fitting and pipeline separation.
- https://scikit-learn.org/stable/model_persistence.html — save complete pipeline and record matching dependency versions.

Installed/tested scikit-learn version is 1.8.0; live documentation may describe a newer release. Reproduction should follow the pinned environment, not assume compatibility across versions.
