# Kontrak input/output batch — versi 1.0

Grain input: satu proyek IT pada akhir bulan 2. Satu ID hanya satu baris per batch. Kapasitas default yang diotorisasi: ceil(20% × proyek valid), tie-break Project_ID ascending setelah skor descending.

| Kolom input wajib | Arti/aturan |
|---|---|
| Project_ID | ID teks tidak kosong dan unik dalam batch; whitespace tepi dibuang. |
| Project_Type | Tepat IT; sektor lain belum didukung. |
| Planned_Budget_USD | Anggaran rencana positif, satuan USD; baseline tetap asumsi provisional. |
| Planned_Months | Durasi rencana > 2 bulan. |
| Snapshot_Month | Tepat 2. |
| EV_M1, EV_M2 | Earned value kumulatif bulan 1/2, positif, bulan 2 tidak turun dan masih < budget. |
| AC_M1, AC_M2 | Biaya kumulatif bulan 1/2, positif, bulan 2 tidak turun. |

Seluruh angka wajib finite. Missing kolom menghentikan batch dengan error schema; invalid per baris masuk rejected_rows.csv. ID duplikat menyebabkan semua baris ID terkait ditolak. Kolom outcome atau kolom tambahan tidak dipakai sebagai input model.

Tujuh fitur dihitung di pipeline yang sama: planned_months, log_budget=log1p(budget), EV2/budget, AC2/budget, CPI2=EV2/AC2, (EV2−EV1)/budget, (AC2−AC1)/budget. Bukan PV/SPI atau hasil akhir. Uji input tidak membuktikan semantic as-of, sehingga G01 tetap HOLD.

Output `predictions.csv`: ID, pengukuran sumber, Risk_Score, CPI_M2, ranking, flag Selected_For_Review, Run_ID, Model_Version, Gate, Data_Mode dan Review_Group. Outcome historis hanya ditautkan setelah scoring ke `historical_reconciliation.csv`; file itu tidak dibuat untuk input custom dengan outcome tidak diketahui. Dashboard HTML mempertahankan hasil evaluasi historis sebagai konteks terpisah.

Output `rejected_rows.csv`: ID, alasan, Run_ID. Output `run_summary.json`: received, accepted, rejected, review_count, capacity dan rekonsiliasi. Harus received = accepted + rejected.

Output `review_queue_draft.csv`: hanya antrean kerja yang belum direview; owner, target dan keputusan kosong. Bukan RAID baru, bukan mitigasi selesai. Pemilik tindakan diisi berdasarkan review sungguhan/simulasi yang dinyatakan eksplisit, bukan digenerasikan sebagai histori palsu.

Input custom diperlakukan sebagai demonstrasi sintetis, bukan data produksi. Nilai skor dan ranking boleh ditampilkan; precision/recall baru tidak dihitung tanpa outcome yang sah. Model hanya memprediksi kelas keterlambatan, bukan jumlah hari terlambat, biaya tambahan atau EAC.

Source replay adalah 277 ID test historis yang sudah dipakai pada Tahap 5. Nama/ID tidak diganti untuk menyamarkan data lama sebagai data baru. Tiga QA_INVALID_* adalah fixture invalid yang disengaja untuk menguji penolakan, bukan proyek atau insiden perusahaan.
