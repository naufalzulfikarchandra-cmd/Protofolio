# Lokasi hasil dan status distribusi

Pembaruan aktual 6 November 2026.

[Folder Google Drive proyek](https://drive.google.com/drive/folders/18-5alhJlEk8_17UMUbeScr1PCREETElI)

GitHub belum berhasil diisi. Akun naufalzulfikarchandra-cmd terhubung tetapi belum ada repository yang terlihat. Koneksi tidak menyediakan pembuatan repository, dan login Google pada browser menampilkan Something went wrong. KAN-38 tetap In Progress dengan dependency D03 terbuka.

Berkas sumber lengkap sudah disiapkan. Setelah owner menyediakan repository berisi README dan URL, struktur paket dapat dipindahkan tanpa training ulang. Pengaturan visibilitas repository tetap pilihan owner. Jangan menganggap URL tujuan atau commit ada sebelum keberhasilannya diverifikasi.

KAN-36, KAN-37 dan KAN-39 berada pada In Review untuk penerimaan owner.

## Berkas inti

- [README.md](https://drive.google.com/file/d/16pHl8GuVLDixKJOv9Sc4g9PBabNSBC_E/view?usp=drivesdk)
- [CASE_STUDY.md](https://drive.google.com/file/d/1JgixMcgMINMl3wLJ2YynOidCqvyVheYm/view?usp=drivesdk)
- [CV_DAN_INTERVIEW.md](https://drive.google.com/file/d/1fxa8O5lLGJwbYmdbb8_0ZG8NFzLUPvP2/view?usp=drivesdk)
- [HANDOVER.md](https://drive.google.com/file/d/1UBBoyF-8BVtVUS15LbJWePDavN-YR6hx/view?usp=drivesdk)
- [RUNBOOK.md](https://drive.google.com/file/d/1BR3_gG5-M4Dsd57LERrruac0P2s2avqf/view?usp=drivesdk)
- [ACCEPTANCE_CHECKLIST.csv](https://drive.google.com/file/d/1EiepKncCvMicd17OdDvyScBgMUxR8qPk/view?usp=drivesdk)
- [11_RAID_Risk_Governance.xlsx](https://docs.google.com/spreadsheets/d/1uGcGeAIZBGOF59ZIbPdmgz-4NUIvtH1R/edit?usp=drivesdk&ouid=112309443888992497182&rtpof=true&sd=true)
- [RAID_Current.csv](https://drive.google.com/file/d/1TnVfDCfEOH0wcdMDZknBcNUpFvf7i3pu/view?usp=drivesdk)
- [RAID_Change_Log.csv](https://drive.google.com/file/d/18xNphHz4-QjtkvbGU5KdZwJ3_4jgljRG/view?usp=drivesdk)
- [decision_register.csv](https://drive.google.com/file/d/1XQeCnUueBviVXNlv_ppJxbWOgMADmsET/view?usp=drivesdk)
- [lesson_register.csv](https://drive.google.com/file/d/1-z9dDhkF7_6oA2a96T3BVOZNN5f7oL8B/view?usp=drivesdk)
