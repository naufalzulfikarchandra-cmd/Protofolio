from pathlib import Path
import json,ast,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/tahap8';P=O/'AI_Project_Risk_Monitoring'
d=json.loads((R/'outputs/tahap6_html/embedded_data.json').read_text());a=json.loads((O/'raid_current.json').read_text());j=json.loads((O/'jira_snapshot.json').read_text())
for row in d['delivery']:
 it=next(x for x in j['issues'] if x['key']==row['Jira']);row['Status']=it['status'];row['Task']=it['summary'].split('] ',1)[-1]
d['raid']=[dict(ID=r[0],Type=r[1],Item=r[2],Status=r[5],Owner_Role=r[6],Actual_PIC=r[7],Source=r[4],Jira=r[9]) for r in a['rows']]
d['gates']=[dict(Gate=g[0],Name=g[1],Status=g[2],Evidence=g[3]) for g in a['gates']]
d['metadata'].update(version='HTML-1.2-Handover',authoring_date='2026-11-06',pmo_snapshot_stage=8,raid_current_count=len(a['rows']),jira_sync_mode='Manual verified snapshot, not live')
template=(R/'outputs/tahap6_html/dashboard_template.html').read_text()
template=template.replace('Portofolio PMO • Tahap 6','Portofolio PMO • Handover Tahap 8').replace('RAID · snapshot awal','RAID · status terkini').replace('13 catatan dari snapshot simulasi 21 Jan 2027. Tidak ditimpa oleh tindakan browser.','16 catatan berdasarkan bukti sampai 6 Nov 2026. Snapshot awal tetap disimpan dalam workbook.').replace('STATUS SNAPSHOT','STATUS TERKINI').replace('${rows.length} dari 13 catatan snapshot awal','${rows.length} dari ${D.raid.length} catatan terkini').replace('raid_snapshot_awal.csv','raid_current_snapshot.csv').replace('<option>In Review</option><option>To Do</option>','<option>In Review</option><option>In Progress</option><option>To Do</option>')
encoded=json.dumps(d,ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
(P/'dashboard/dashboard_template.html').write_text(template)
(P/'dashboard/embedded_data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
(P/'dashboard/Dashboard_PMO_HTML.html').write_text(template.replace('__DASHBOARD_DATA__',encoded))
guide=(R/'outputs/tahap6_html/Panduan_HTML.md').read_text().replace('Versi HTML-1.1','Versi HTML-1.2-Handover').replace('13 catatan RAID awal','16 catatan RAID terkini').replace('snapshot Jira 6 November 2026','snapshot Jira terverifikasi sampai Tahap 8 pada 6 November 2026')
guide+='\n## Pembaruan handover\n\nVersi paket ini memperbarui snapshot Jira, RAID dan gate berdasarkan hasil aktual Tahap 8. Snapshot awal 13 catatan tetap disimpan di workbook. D03 menyimpan kendala repository GitHub sampai bukti unggah tersedia. Tabel delivery bukan koneksi live. Skor, model, kapasitas dan finansial tidak diubah.\n'
(P/'dashboard/Panduan_HTML.md').write_text(guide)
src=(R/'outputs/tahap6_html/Colab_Batch_ke_HTML.py').read_text();lines=src.splitlines(keepends=True)
nodes=[n for n in ast.parse(src).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['HTML_TEMPLATE','BASE_DATA'] for t in n.targets)]
for n in sorted(nodes,key=lambda n:n.lineno,reverse=True):
 name=n.targets[0].id;value=template if name=='HTML_TEMPLATE' else json.dumps(d,ensure_ascii=False)
 lines[n.lineno-1:n.end_lineno]=[name+' = '+repr(value)+'\n']
code=''.join(lines);compile(code,'handover_notebook','exec')
(P/'code/batch/Colab_Batch_ke_HTML.py').write_text(code)
nb=json.loads((R/'outputs/tahap6_html/Colab_Batch_ke_HTML.ipynb').read_text())
for c in nb['cells']:
 if c['cell_type']=='code':c['source']=code.splitlines(keepends=True);c['execution_count']=None;c['outputs']=[]
nb['cells'][0]['source'].append('\nSnapshot PMO handover Tahap 8, 6 November 2026. Status Jira dan RAID adalah snapshot manual, bukan sinkronisasi live.\n')
(P/'code/batch/Colab_Batch_ke_HTML.ipynb').write_text(json.dumps(nb,ensure_ascii=False,indent=2))
shutil.copy2(O/'11_RAID_Risk_Governance.xlsx',P/'governance/11_RAID_Risk_Governance.xlsx')
for n in ['RAID_Current.csv','Gate_Current.csv','RAID_Change_Log.csv','raid_current.json']:shutil.copy2(O/n,P/'governance'/n)
test=(R/'qa/test_html_stage6.cjs').read_text()
test=test.replace("require('./html_dom_test/node_modules/jsdom')","require('/workspace/scratch/bd14fc04d8ab/qa/html_dom_test/node_modules/jsdom')").replace("path.resolve('outputs/tahap6_html/Dashboard_PMO_HTML.html')","path.resolve('outputs/tahap8/AI_Project_Risk_Monitoring/dashboard/Dashboard_PMO_HTML.html')").replace("children.length,13","children.length,16").replace("'outputs/tahap6_html/verification.json'","'outputs/tahap8/AI_Project_Risk_Monitoring/results/qa_html/handover_verification.json'")
test=test.replace("fs.writeFileSync(","check('handover_governance_snapshot',()=>{assert.equal(w.eval('D.raid.length'),16);assert(w.eval('D.raid.some(r=>r.ID===\"I06\")'));assert(d.querySelector('#view-governance h2').textContent.includes('terkini'))});\ncheck('handover_jira_matches_source',()=>{const observed=JSON.parse(fs.readFileSync('outputs/tahap8/jira_snapshot.json','utf8'));for(const r of observed.issues)assert.equal(w.eval('D.delivery').find(x=>x.Jira===r.key).Status,r.status)});\nfs.writeFileSync(")
(R/'qa/tahap8/test_handover_html.cjs').write_text(test)
print('Refreshed handover HTML and notebook PMO metadata only')
