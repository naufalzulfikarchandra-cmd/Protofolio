from pathlib import Path
import json,shutil,csv,hashlib,zipfile,re,ast
R=Path(__file__).resolve().parents[1];O=R/'outputs/tahap8';P=O/'AI_Project_Risk_Monitoring';P.mkdir(parents=True,exist_ok=True)
def write(rel,text):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')
def cp(src,dst):
 p=P/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/src,p)
write('README.md','''
# AI Project Risk Monitoring

**PMO Risk Dashboard — independent portfolio simulation by Naufal Zulfikar Chandra, developed with AI assistance.**

This project demonstrates how a PMO can plan and govern an AI initiative, evaluate evidence and turn model outputs into a review workflow. The dashboard is an offline HTML application. The prediction engine remains an exploratory synthetic benchmark with operational gate **G01 HOLD**.

## Start here

1. Open `dashboard/Dashboard_PMO_HTML.html` in Chrome, Edge or Firefox. No installation or server is required for the recorded demo.
2. Read [the portfolio case study](portfolio/CASE_STUDY.md) for the problem, PMO decisions and results.
3. Read [the handover guide](handover/HANDOVER.md) and [runbook](handover/RUNBOOK.md) to navigate the package or reproduce a recorded workflow.
4. Review [open items](handover/OPEN_ITEMS.md) before accepting the deliverables.

## Recorded results

| Measure | Recorded value |
|---|---:|
| Synthetic source projects | 4,000 |
| Project month observations | 72,549 |
| Eligible IT project cohort | 1,381 |
| Held out test projects / late cases | 277 / 188 |
| Review capacity | 20% = 56 priorities |
| RF late cases found in top 56 | 44 |
| CPI rule late cases found in top 56 | 39 |
| RF precision / recall at 56 | 78.57% / 23.40% |
| Late cases outside the RF priority list | 144 |

The 95% paired bootstrap interval for the recall difference is −2.05 to +7.49 percentage points. It includes zero. The advantage is inconclusive and does not establish real world impact. Scores are provisional synthetic outputs rather than validated company risk probabilities.

## PMO scope

The eight work stages cover initiation, planning, budgeting, RAID and governance, model evidence, batch and HTML integration, reporting and decisions, and handover and portfolio preparation. The planning baseline has 28 tasks and 93 planned hours. Dates and company cost allocations are simulated. User acceptance remains separately recorded.

The budget snapshot uses IDR and a simulated cutoff of 27 January 2027. BAC is Rp19,739,881.625 and EAC Base is Rp20,140,066.625. The Rp400,185 forecast overrun is 2.03%. The snapshot has not been reforecast after the HTML change or net Option B effort. Source project budgets use USD and are not added to the implementation budget.

## Structure

| Folder | Content |
|---|---|
| `docs` | Approved scope of document preparation and stage outputs, with owner review still pending |
| `governance` | Current RAID, gates, decision and lessons registers, with an original snapshot retained |
| `portfolio` | Case study, CV wording and interview preparation |
| `handover` | Runbook, acceptance checklist, open items and attribution |
| `dashboard` | Standalone HTML, template, embedded PMO snapshot and user guide |
| `code` | Existing training and batch engines and Colab notebooks |
| `data` | Original supplied synthetic data and demo inputs |
| `model` / `results` | Existing model artifact, protocol results, split and execution evidence |
| `artifacts` | Original user supplied Colab result ZIP |

## Status and next decision

Option B means reviewing data provenance and feature availability before deciding whether retraining is necessary. The proposed check is 6 Data hours plus 2 PMO review hours. It has not been executed. Changes to names or dashboard appearance alone do not require a new model. Owner browser UAT and acceptance remain open.

This package is a portfolio handover, not production approval. No company deployment, cash savings or reduction in project delays has been measured. Read [sources and rights](handover/SOURCES_AND_RIGHTS.md) before reuse. No new blanket software license is granted by this README.
''')
write('portfolio/CASE_STUDY.md','''
# AI Project Risk Monitoring

## Project profile

Independent PMO portfolio simulation by Naufal Zulfikar Chandra, completed with AI assistance for document preparation, coding and analysis. The project studies how an internal PMO could prioritise project reviews using early project measurements. It does not represent employment at a real client or an implemented company system.

## Business problem and intended decision

A PMO with limited review capacity needs a consistent way to identify projects that deserve earlier attention. A risk score is only useful if its inputs would have been known when the review decision was made, and if the review queue fits available capacity. The simulated objective is to support review prioritisation, not to automate project decisions or guarantee delivery outcomes.

## My role and use of AI

I initiated and directed the project, chose the portfolio objective, constrained spending, selected the 20% demo review capacity, corrected stage boundaries and changed the dashboard delivery from Power BI to HTML when the original approach did not meet my needs. AI assisted with the preparation of project documents, pipeline code, analysis and dashboard. Formal acceptance of the resulting package and user testing are still separate tasks.

The PMO skills demonstrated are scope definition, work breakdown, budget assumptions, change control, evidence review, risk governance, status reporting and decision preparation. The technical artifacts support those skills; they are not presented as software I personally wrote without assistance.

## Delivery approach

| Stage | Main artifact |
|---|---|
| Initiation | Business case, charter, stakeholder and governance documents |
| Planning | 28 task WBS, simulated schedule, RACI and Jira backlog |
| Budget | Baseline allocation, simulated cost ledger, forecast and cost definitions |
| Governance | RAID snapshot, control gates and mitigation plan |
| Data and model | Source audit, month 2 snapshot, split, rule and ML evaluation |
| Integration | Validated batch output, offline HTML dashboard and manual review queue |
| Reporting | Project status report, options brief, steering slides and lessons |
| Handover | Source package, runbook, case study, acceptance checklist and CV material |

## Data and modelling choices

The supplied synthetic benchmark contains 4,000 projects and 72,549 project month observations. The IT cohort has 1,381 projects. A month 2 snapshot uses seven features from planned duration, budget, EV and AC. The fixed project split is 828 training, 276 validation and 277 test projects.

The comparison included Logistic Regression and Random Forest alongside a CPI rule. Validation average precision selected calibrated Random Forest depth 4. XGBoost was not a project requirement. Final outcomes and project identifiers were excluded as predictors. PV, SPI and SV were excluded after data concerns were identified. Baseline freeze and semantic feature availability remain unproven, so G01 remains HOLD.

## Results at the chosen capacity

At 20% review capacity, 56 of the 277 test projects enter the priority list. Random Forest finds 44 late cases compared with 39 from the CPI rule. Precision is 78.57% and recall is 23.40%. There are 188 late cases in the test set, so 144 remain outside the RF queue.

The five additional cases are an internal synthetic test result. The bootstrap interval for the recall difference spans zero. I therefore retain an inconclusive comparison rather than claiming the AI is operationally superior. Diagnostic recall at a 0.5 threshold is 93.09%, but it requires 253 alerts and does not describe the selected capacity of 56.

## PMO decisions and control of change

The dashboard output changed to HTML by user direction. The earlier Power BI package is superseded, and the original baseline remains part of the history. The current package does not claim an agreed revised effort or cost baseline for that change.

The budget uses simulated company allocations. At the original simulated cutoff, EAC exceeds BAC by Rp400,185, or 2.03%. Those numbers are not personal expenditure or an updated forecast after every later change. Option B proposes a bounded data review first. Its gross effort estimate is not automatically added to EAC because the old Base scenario already contains rework allowances.

## What is available and what remains open

The HTML supports filtering, search, ranking, project details, scenario comparison, CSV import and export, and a review queue requiring manual evidence. The existing evidence records 21 DOM interaction checks and full notebook execution with simulated Colab upload and download. These checks do not constitute owner UAT in Windows.

Open items include feature availability evidence, owner UAT, the net cost and schedule effect of scope changes, and formal package acceptance. Lessons and current RAID are in the governance folder. No operational cost saving, reduction in delays, production rollout or real company stakeholder approval is claimed.

## Why this is relevant to a PMO role

This case demonstrates a PMO decision to keep an attractive AI demo within its evidence limits, compare options at the same review workload, preserve the baseline when tools change, and produce a traceable handover. The main outcome is a usable management and demonstration package with explicit unresolved decisions.
''')
write('handover/HANDOVER.md','''
# Panduan handover

Pemilik portofolio: Naufal Zulfikar Chandra. Nama proyek: AI Project Risk Monitoring. Deskripsi: PMO Risk Dashboard. Disiapkan aktual 6 November 2026 untuk review owner.

## Tujuan paket

Paket menyatukan keluaran delapan tahap dan cara menggunakannya. Ketersediaan berkas, keberhasilan unggah, penerimaan owner dan kelayakan operasional model adalah empat hal yang dinilai terpisah. Model tetap G01 HOLD. Peran perusahaan selain owner aktual merupakan simulasi.

## Urutan membaca

Mulai dari README, portfolio/CASE_STUDY.md, docs/tahap7/01_Laporan_Status_Proyek.docx, kemudian brief Opsi B. Buka dashboard/Dashboard_PMO_HTML.html untuk demo. Gunakan governance/11_RAID_Risk_Governance.xlsx pada sheet Current_RAID dan Gate_Updates untuk status terkini. Lima sheet awal workbook mempertahankan snapshot SIM 21 Januari 2027. Change_Log menunjukkan perkembangan berbasis bukti.

Dokumen tahap sebelumnya adalah rekaman pada waktu penulisannya. Instruksi lama mengenai Power BI ditunda bukan instruksi alat yang berlaku sekarang. Keluaran dashboard terkini adalah HTML. Angka evaluasi legacy 46 vs 44 tidak menggantikan hasil RF Tahap 5 yaitu 44 vs 39.

## Waktu dan biaya

Tanggal aktual paket adalah 6 November 2026. Baseline cerita SIM Tahap 8 adalah 10 sampai 15 Februari 2027 dengan empat task masing masing 3 jam. Ini tidak membuktikan pekerjaan berlangsung pada tanggal tersebut atau menghabiskan jam aktual tersebut. Cutoff keuangan tetap 27 Januari 2027. Tidak ada timesheet baru, forecast baru atau persetujuan biaya yang dibuat melalui handover.

## Penanggung jawab penggunaan

Owner aktual meninjau narasi dan menjalankan UAT pada perangkatnya. Data Owner, ML Lead, Finance Reviewer dan Operations merupakan peran tanggung jawab simulasi. Tidak ada pegawai baru yang ditugaskan. Perubahan owner, tanggal review dan keputusan hanya dicatat bila benar benar diberikan.

## Penerimaan

Gunakan ACCEPTANCE_CHECKLIST.csv dan isi hasil, tanggal aktual serta referensi bukti. Kolom hasil awal kosong karena owner belum melakukan review. Sebelum menyatakan diterima, cocokkan langkah demo, data test, batas model, sumber, biaya dan tautan distribusi. Tiket tetap In Review atau In Progress sesuai bukti, bukan otomatis Done.

## Pemeliharaan

Simpan ekspor review CSV sebelum berpindah browser. Draft localStorage tidak otomatis tersinkron ke Jira atau RAID. Status Jira dan RAID di HTML adalah snapshot yang memiliki waktu pembaruan, bukan koneksi live. Bila kode, fitur, label atau sumber berubah, buat versi baru beserta manifest dan evaluasi yang sesuai. Mengganti teks atau nama produk tidak mengharuskan training ulang.

Jika proses batch gagal, periksa schema input dan rejected_rows.csv. Pertahankan paket hasil terakhir yang berhasil. Jangan menimpa split atau model lama untuk menyamarkan perubahan. Rencana Opsi B belum dieksekusi dan mengikuti keputusan lanjutan.
''')
write('handover/RUNBOOK.md','''
# Runbook penggunaan dan reproduksi

## Demo tanpa setup

Ekstrak paket lengkap. Buka dashboard/Dashboard_PMO_HTML.html di browser. Data demo tertanam. Kapasitas awal adalah 20% atau 56 prioritas dari 277 proyek. Tidak ada model yang dijalankan di JavaScript. Impor predictions.csv hanya membaca skor dari hasil batch.

## Batch di Google Colab

Unggah code/batch/Colab_Batch_ke_HTML.ipynb ke Colab. Jalankan satu sel kode. Ketika pemilih file muncul, pilih artifacts/HASIL_Colab_Tahap5.zip. CSV input batch bersifat opsional. Tanpa CSV tambahan, notebook memakai replay historis test yang sudah ada. Unduh ZIP keluaran, ekstrak lalu buka HTML.

Notebook memeriksa paket yang diperlukan dan memasang hanya dependensi yang belum tersedia. Tidak perlu memasang GPU atau layanan berbayar. Gunakan paket hasil model milik proyek ini. Mode pemuatan dan versi tercatat dalam model_trace.json. Pada runtime yang tidak cocok, engine mereproduksi model terpilih pada train asli dengan parameter terkunci, tanpa tuning pada test. Jadi menjalankan batch di environment lain dapat menjalankan fit untuk kompatibilitas. Hal tersebut tidak terjadi hanya dengan membuka dashboard.

## Menjalankan batch lokal

Lingkungan sumber yang diuji adalah Python 3.12 dengan versi paket di code/training/requirements.txt. Dari folder code/batch, panggil fungsi run_stage6 dengan path ZIP dan direktori hasil. Entry point yang disediakan dalam paket adalah notebook satu sel; tidak ada klaim bahwa batch_engine.py memiliki CLI sendiri.

CSV mentah memakai sembilan kolom yang dijelaskan dalam DATA_CONTRACT.md. Angka harus finite, budget positif, sektor IT, snapshot bulan 2, nilai kumulatif tidak menurun dan ID unik. Input invalid dipisahkan dengan alasan. Output harus memenuhi received = accepted + rejected. Pada replay yang direkam, 280 diterima sebagai input, 277 lolos dan 3 fixture QA ditolak.

## Reproduksi training historis

Langkah ini adalah cara mengulangi benchmark yang sudah ada, bukan instruksi melaksanakan usulan Opsi B. Jangan gunakan hasil test lama untuk tuning berulang.

```bash
python -m pip install -r code/training/requirements.txt
python code/training/train_stage5.py --source-dir data/source --output-dir reproduced_training
```

Kode membaca tiga file sumber yang disertakan, membangun snapshot, memakai split seed 20261104 dan menghasilkan hasil pada direktori baru. Dua XLSX sumber mengandung CSV satu kolom dan parser menangani format tersebut. Input, protokol dan environment tercatat. Hasil lintas versi dapat sedikit berbeda. Paket menyimpan hasil historis dan manifest sebagai pembanding, bukan menjanjikan semua environment identik.

Untuk alur Colab langsung, buka code/training/Colab_Langsung_Jalan.ipynb dan unggah tiga sumber yang diminta. Jangan memilih notebook lama yang mencari folder Drive. Alur ini menjalankan training bila user mengeksekusinya, sedangkan handover saat ini hanya mengemas kode yang sudah tersedia.

## Batas interpretasi

Kolom outcome pada data historis hanya untuk evaluasi. Model tidak memprediksi jumlah hari terlambat atau EAC implementasi. Untuk CSV custom, outcome belum diketahui dan hasil evaluasi pada dashboard tetap benchmark historis. As of fitur belum terbukti dan G01 tetap HOLD.
''')
write('handover/OPEN_ITEMS.md','''
# Hal terbuka saat handover

| Item | Kondisi | Bukti yang diperlukan untuk menutup |
|---|---|---|
| G01 dan as of fitur | HOLD | Provenance, freeze baseline dan waktu tersedia EV AC diterima owner |
| Opsi B | Usulan pemeriksaan data 8 jam, belum dilakukan | Hasil pemeriksaan dan keputusan tindak lanjut, termasuk kebutuhan training bila ada |
| G02 | Belum disetujui | Review sumber, hak penggunaan dan hasil pemeriksaan akses |
| G03 dan I05 | Owner UAT belum diterima | Checklist dengan hasil, tanggal dan bukti Windows browser |
| I06 | Forecast lama | Rekonsiliasi scope HTML dan overlap rework sebelum forecast baru |
| G04 | Review handover terbuka | Owner menerima berkas, runbook dan batas klaim |
| D03 dan KAN-38 | Distribusi GitHub menunggu repository atau autentikasi browser | Repository dan commit yang berhasil diverifikasi |

Keberhasilan distribusi Drive dan GitHub dicatat pada laporan pelaksanaan aktual. Ketiadaan penerimaan owner tidak disamarkan sebagai persetujuan sponsor. Tidak ada pekerjaan Opsi B atau operasi perusahaan yang direkayasa untuk menutup item.
''')
write('handover/SOURCES_AND_RIGHTS.md','''
# Sumber dan hak penggunaan

## Dataset

Reyhane Hajihoseyni (2026). Simulated project risk and earned value dataset, version 1. Mendeley Data. DOI 10.17632/2p5sz57wh2.1. https://data.mendeley.com/datasets/2p5sz57wh2/1 . Lisensi sumber CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Halaman metadata diperiksa 6 November 2026.

Data sumber merupakan benchmark sintetis. Tiga berkas yang dipakai adalah project_risk_raw_dataset.csv, simulated_project_ev_metrics_final.csv.xlsx dan project_delay_cost_overrun_summary_final.csv.xlsx. Paket mempertahankan byte sumber yang dipakai dalam eksperimen. Halaman metadata tidak menjadi bukti bahwa generator atau waktu tersedia fitur telah diaudit. Hash sumber ada pada results/stage5/environment.json.

Transformasi proyek mencakup parsing XLSX berisi CSV satu kolom, pembentukan snapshot akhir bulan 2 untuk proyek IT, feature engineering, split proyek, pelatihan benchmark terdahulu dan keluaran evaluasi. Penulis dataset tidak memberi endorsement atas proyek ini. Atribusi dan lisensi sumber harus dipertahankan saat dataset dibagikan ulang.

## Kode dan dokumen

Naufal Zulfikar Chandra mengarahkan proyek portofolio dengan bantuan AI untuk penulisan, kode dan analisis. Tidak ada lisensi perangkat lunak baru yang dipilih atas nama owner dalam penugasan ini. Lisensi dataset tidak otomatis menjadi lisensi seluruh repository. Dependensi tetap memakai ketentuan penerbit masing masing.

## Anggaran dan praktik dokumentasi

Basis benchmark biaya dan keterbatasannya tersedia pada docs/tahap3/10_Laporan_Budget_dan_Log.md. Tarif merupakan snapshot lama, bukan harga yang ditawarkan ulang. Rujukan lessons learned ada pada source register Tahap 7. Panduan README GitHub: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes .
''')
write('portfolio/CV_DAN_INTERVIEW.md','''
# Materi CV dan interview

## Entri proyek pada CV berbahasa Indonesia

**AI Project Risk Monitoring — Proyek Portofolio PMO dengan Bantuan AI**

- Menyusun portofolio simulasi pengelolaan inisiatif AI melalui delapan tahap, mencakup WBS 28 task, anggaran simulasi, RAID, tata kelola dan pelaporan keputusan.
- Mengarahkan dashboard HTML untuk prioritisasi review 20%, serta menilai hasil benchmark sintetis 277 proyek test dengan menampilkan pembanding, beban review dan keterbatasan model.
- Mendokumentasikan perubahan alat, status gate HOLD, rencana pemeriksaan data dan paket handover dengan jejak bukti serta panduan reproduksi.

## CV wording in English

**AI Project Risk Monitoring — AI assisted PMO Portfolio Simulation**

- Developed an eight stage PMO portfolio simulation covering a 28 task WBS, simulated budgeting, RAID governance and decision reporting with AI assistance.
- Directed an offline HTML review dashboard using a 20% capacity scenario and assessed synthetic model evidence across 277 test projects against a CPI rule.
- Documented tool changes, model HOLD criteria, data review options and a traceable handover package with reproduction instructions.

Tempatkan entri pada bagian Projects, bukan pengalaman kerja perusahaan. Tidak ada gelar pekerjaan, tanggal masa kerja, deployment produksi, penghematan atau stakeholder perusahaan nyata yang ditambahkan.

## Narasi pembuka sekitar satu menit

Saya membuat AI Project Risk Monitoring sebagai simulasi portofolio untuk memperlihatkan cara saya mengarahkan dan mengendalikan inisiatif AI dari perspektif PMO. Saya menggunakan bantuan AI untuk kode dan dokumen, sementara saya menetapkan arah, membatasi lingkup serta mengoreksi keputusan yang tidak sesuai. Dashboard akhirnya memakai HTML agar demo dapat dibuka langsung. Pada kapasitas review 56 dari 277 proyek test sintetis, model menangkap 44 kasus terlambat dibanding 39 oleh aturan CPI. Saya tetap mencatat hasilnya belum konklusif dan menahan penggunaan operasional karena bukti waktu tersedia fitur belum cukup. Yang saya tunjukkan adalah proses pengendalian dan keputusan berbasis bukti, disertai artefak yang dapat diperiksa.

## Alur demo sekitar lima menit

| Waktu | Materi yang ditunjukkan | Pesan |
|---|---|---|
| Menit 0 sampai 1 | README dan business case | Masalah prioritisasi review dan tujuan simulasi |
| Menit 1 sampai 2 | WBS, budget dan Jira | Perencanaan, status review dan batas actual SIM |
| Menit 2 sampai 3 | Risk Monitoring dan Model Evaluation | 56 prioritas, 44 vs 39, serta 144 kasus terlewat |
| Menit 3 sampai 4 | Current RAID dan brief Opsi B | Mengapa model HOLD dan opsi tindak lanjut |
| Menit 4 sampai 5 | Runbook dan checklist handover | Reproduksi, batas QA dan penerimaan yang masih terbuka |

## Pertanyaan yang perlu dapat dijelaskan

**Mengapa memakai AI jika aturan sederhana sudah ada?** Tujuannya menguji apakah ranking AI membantu pada beban review yang sama. Lima tambahan kasus pada test sintetis belum membuktikan keunggulan konklusif, jadi keputusan penggunaan tidak dipaksakan.

**Apa arti melatih model?** Algoritma mempelajari hubungan fitur dan label dari subset training. Validation memilih konfigurasi. Test dipakai untuk penilaian akhir, bukan untuk tuning setelah hasil dilihat. Model tabular ini menggunakan CPU dan tidak membutuhkan pendekatan NLP atau IndoBERT.

**Mengapa kapasitas 20%?** Itu skenario demo yang saya pilih. Dengan 277 proyek, pembulatan ke atas menghasilkan 56 prioritas. Itu bukan bukti kapasitas staffing suatu perusahaan.

**Mengapa status model HOLD?** Pemisahan train dan test saja belum membuktikan fitur benar benar tersedia pada saat prediksi. Bukti generator dan pembekuan baseline belum cukup. Opsi B memeriksa hal tersebut sebelum memutuskan training ulang.

**Apakah proyek ini menghemat biaya perusahaan?** Belum ada pengukuran itu. Anggaran adalah alokasi simulasi, dan hasil model adalah benchmark sintetis. Saya tidak mengubahnya menjadi klaim penghematan atau penurunan keterlambatan.

**Apa yang Anda kerjakan sendiri dan apa bantuan AI?** Saya mengarahkan tujuan, lingkup, kapasitas demo, pilihan alat serta koreksi konteks. AI membantu membuat kode, analisis dan dokumen. Saya perlu memahami dan meninjau artefak sebelum menggunakannya dalam lamaran.

**Apa yang akan diperbaiki berikutnya?** Memperkuat bukti as of, melengkapi UAT, merekonsiliasi dampak perubahan terhadap forecast, lalu mencatat keputusan owner. Tidak menjanjikan model baru sebelum hasil pemeriksaan data.
''')
write('.gitignore','''
__pycache__/
*.py[cod]
.venv/
reproduced_training/
my_run/
.env
.env.*
''')
checks=[('UAT01','Buka HTML di Windows','Lima tab tampil dan Risk Monitoring memuat277 valid56 prioritas'),('UAT02','Filter cari urut dan pindah halaman','Baris dan count mengikuti filter tanpa error'),('UAT03','Lihat evaluasi historis','Top56 RF44 CPI39, recall23,40% dan batas sintetis jelas'),('UAT04','Impor predictions CSV valid','Ranking dihitung dari skor valid, metrik historis tetap terpisah'),('UAT05','Impor CSV ID ganda atau skor invalid','Baris invalid ditolak dengan pesan, data lama tidak hilang saat gagal'),('UAT06','Selesaikan review tanpa bukti','Owner tanggal dan catatan wajib sebelum status review selesai'),('UAT07','Simpan pulihkan dan ekspor review','Catatan tersimpan pada perangkat jika didukung dan CSV dapat dibuka'),('UAT08','Jalankan notebook batch di Colab','Replay menghasilkan280input277valid3fixtureditolak56prioritas'),('UAT09','Periksa paket dan hak sumber','Atribusi tersedia dan tidak ada credential yang dibagikan'),('UAT10','Review studi kasus dan CV','Klaim sesuai simulasi dan bantuan AI dinyatakan'),('UAT11','Periksa tautan distribusi','File Drive dan repository benar benar dapat diakses owner'),('UAT12','Terima handover dengan batas model','Owner mencatat keputusan penerimaan tanpa mengubah G01 otomatis')]
with (P/'handover/ACCEPTANCE_CHECKLIST.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['ID','Skenario','Hasil yang diharapkan','Status pelaksanaan owner','Hasil aktual','Tanggal aktual','Pelaksana','Referensi bukti']);w.writerows([*c,'Belum dijalankan','','','',''] for c in checks)

for folder,files in {
'initiasi':['01_Business_Case.docx','02_Project_Charter.docx','03_Stakeholder_Register.xlsx','04_Governance_Structure.docx'],
'tahap2':['06_Project_Planning_Master.xlsx','08_Jira_Backlog.csv','07_Log_Pekerjaan_Tahap_2.md'],
'tahap3':['09_Budget_Management.xlsx','10_Laporan_Budget_dan_Log.md','budget_results.json'],
'tahap4':['12_Mitigation_dan_Control_Plan.md','13_Log_Pekerjaan_Tahap_4.md'],
'tahap5':['14_Laporan_Tahap_5.md','16_Log_Pekerjaan_Tahap_5.md'],
'tahap6_html':['Laporan_dan_Log_Revisi_HTML.md'],
'tahap7':['01_Laporan_Status_Proyek.docx','02_Brief_Keputusan_Opsi_B.docx','03_Lessons_Learned.docx','04_Presentasi_Steering.pptx','05_Log_Pekerjaan_Tahap_7.md','source_register.json']}.items():
 for name in files:cp('outputs/'+folder+'/'+name,'docs/'+folder+'/'+name)
cp('outputs/tahap4/11_RAID_Risk_Governance.xlsx','governance/history/RAID_Snapshot_Awal.xlsx')
for n in ['RAID_Current.csv','Gate_Current.csv','RAID_Change_Log.csv','raid_current.json']:cp('outputs/tahap8/'+n,'governance/'+n)
for n in ['decision_register.csv','lesson_register.csv']:cp('outputs/tahap7/'+n,'governance/'+n)
for n in ['Dashboard_PMO_HTML.html','dashboard_template.html','embedded_data.json','Panduan_HTML.md','DATA_CONTRACT.md']:cp('outputs/tahap6_html/'+n,'dashboard/'+n)
for n in ['batch_engine.py','render_html.py','Colab_Batch_ke_HTML.ipynb','Colab_Batch_ke_HTML.py']:cp('outputs/tahap6_html/'+n,'code/batch/'+n)
for n in ['train_stage5.py','protocol.json','requirements.txt']:cp('outputs/tahap5/'+n,'code/training/'+n)
cp('outputs/colab_v2/17_Colab_Langsung_Jalan.ipynb','code/training/Colab_Langsung_Jalan.ipynb')
cp('outputs/colab_v2/18_Kode_Colab_Satu_Sel.py','code/training/Colab_Satu_Sel.py')
for p in (R/'outputs/tahap5/source').iterdir():
 if p.is_file():cp(str(p.relative_to(R)),'data/source/'+p.name)
for n in ['snapshot_month2.csv','split_manifest.csv','data_dictionary.csv']:cp('outputs/tahap5/data/'+n,'data/prepared/'+n)
cp('outputs/tahap6_html/batch_results/template_demo_input.csv','data/examples/template_demo_input.csv')
for n in ['model_card.json','exploratory_model.joblib']:cp('outputs/tahap5/model/'+n,'model/'+n)
for p in (R/'outputs/tahap5/results').iterdir():
 if p.is_file() and p.suffix in ['.json','.csv'] and p.name!='jira_verification.json':cp(str(p.relative_to(R)),'results/stage5/'+p.name)
for n in ['predictions.csv','rejected_rows.csv','run_summary.json','model_trace.json','review_queue_draft.csv','historical_reconciliation.csv']:cp('outputs/tahap6_html/batch_results/'+n,'results/batch/'+n)
for n in ['verification.json','notebook_verification.json']:cp('outputs/tahap6_html/'+n,'results/qa_html/'+n)
cp('outputs/tahap6_html/source/20261105_081133_c9f7c5_HASIL.zip','artifacts/HASIL_Colab_Tahap5.zip')
write('RELEASE_NOTES.md','''
# Catatan paket handover Tahap 8

Disiapkan aktual 6 November 2026. Produk memakai nama AI Project Risk Monitoring dengan deskripsi PMO Risk Dashboard. Dashboard HTML menjadi keluaran yang berlaku dan Power BI tidak dibutuhkan.

Paket menyatukan dokumen, engine terdahulu, hasil historis, dashboard, current RAID, runbook, studi kasus, CV dan checklist penerimaan. Original snapshot RAID dan baseline jadwal serta anggaran dipertahankan. Sumber mentah dan ZIP hasil Colab user disertakan untuk jejak reproduksi.

Tidak ada pelatihan ulang, audit generator baru, data baru atau penerimaan owner yang dijalankan dalam pembuatan paket ini. Usulan Opsi B tetap terpisah. Tidak ada baseline atau actual timesheet baru. Status distribusi aktual dan bukti Jira ada pada laporan Tahap 8 yang disertakan setelah unggah.
''')
print('Prepared files',sum(p.is_file() for p in P.rglob('*')))
