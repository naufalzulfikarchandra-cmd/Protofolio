import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root='/workspace/scratch/bd14fc04d8ab';const out=root+'/outputs/tahap8';
const d=JSON.parse(await fs.readFile(out+'/raid_current.json','utf8'));
const w=await SpreadsheetFile.importXlsx(await FileBlob.load(root+'/outputs/tahap4/11_RAID_Risk_Governance.xlsx'));
const original={};for(const s of w.worksheets.items)original[s.name]={values:s.getUsedRange().values,formulas:s.getUsedRange().formulas};
const view=w.worksheets.getItem('Overview');
view.getRange('A30:B33').values=[['Pembaruan aktual',new Date('2026-11-06T00:00:00Z')],['Status terkini','Lihat Current_RAID dan Gate_Updates'],['Riwayat pembaruan','Lihat Change_Log'],['Snapshot lama','Lima sheet awal tetap riwayat SIM 21 Januari 2027']];view.getRange('B30').setNumberFormat('yyyy-mm-dd');
view.getRange('A30:B33').format.font={name:'Arial',size:10};view.getRange('A30:B33').format.rowHeight=30;
function sheet(name,title,headers,rows,widths,rowHeight=100){
 const s=w.worksheets.add(name);s.showGridLines=false;s.tabColor='#18364A';
 const n=headers.length;const last=String.fromCharCode(64+n);
 s.getRange(`A1:${last}${rows.length+6}`).format.font={name:'Arial',size:10,color:'#172E40'};
 s.getRange('A2').values=[[title]];s.getRange('A2').format.font={name:'Arial',size:15,bold:true};
 s.getRange('A3').values=[['Pembaruan aktual 6 November 2026. Role selain Naufal adalah simulasi.']];
 s.getRange('A3').format.font={italic:true,size:10};
 s.getRange(`A5:${last}5`).values=[headers];s.getRange(`A6:${last}${rows.length+5}`).values=rows;
 s.getRange(`A5:${last}${rows.length+5}`).format.wrapText=true;s.getRange(`A5:${last}${rows.length+5}`).format.verticalAlignment='center';
 s.getRange(`A5:${last}5`).format={fill:'#18364A',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:32,wrapText:true};
 s.getRange(`A6:${last}${rows.length+5}`).format.rowHeight=rowHeight;
 widths.forEach((width,i)=>s.getRange(`${String.fromCharCode(65+i)}1:${String.fromCharCode(65+i)}${rows.length+6}`).format.columnWidthPx=width);
 for(let i=0;i<rows.length;i++)if(i%2===0)s.getRange(`A${i+6}:${last}${i+6}`).format.fill='#F0F4F6';
 s.freezePanes.freezeRows(5);
 s.tables.add(`A5:${last}${rows.length+5}`,true,name.replaceAll('_','')+'Table');
 return s;
}
const cur=sheet('Current_RAID','AI Project Risk Monitoring',['ID','Jenis','Catatan','Bukti terkini','Sumber','Status terkini','Owner simulasi','PIC aktual','Tindak lanjut','Jira terkait'],d.rows,[70,112,285,440,245,275,190,110,350,155],118);
const ga=sheet('Gate_Updates','Gate terkini',['ID','Gate','Status','Bukti','Owner simulasi','PIC aktual','Syarat penerimaan','Sumber'],d.gates,[70,210,160,400,210,110,340,250],110);
const log=sheet('Change_Log','Riwayat pembaruan RAID',['Event','Tanggal aktual','ID terkait','Perubahan berbasis bukti','Dampak','Sumber'],d.events.map(r=>r.map((v,i)=>i===1?new Date(v+'T00:00:00Z'):v)),[100,150,150,460,360,300],92);log.getRange(`B6:B${d.events.length+5}`).setNumberFormat('yyyy-mm-dd');log.getRange(`B6:B${d.events.length+5}`).format.horizontalAlignment='center';
w.recalculate();
const preserved={};for(const [name,old] of Object.entries(original)){if(name==='Overview')continue;const s=w.worksheets.getItem(name);preserved[name]=JSON.stringify(old.values)===JSON.stringify(s.getUsedRange().values)&&JSON.stringify(old.formulas)===JSON.stringify(s.getUsedRange().formulas);}
if(!Object.values(preserved).every(Boolean))throw Error('Original source sheets changed');
await fs.writeFile(root+'/qa/tahap8/raid_preservation.json',JSON.stringify({preserved,old_snapshot_rows:13,current_rows:d.rows.length,original_inherent_and_residual_scores_unchanged:true},null,2));
for(let row=5;row<=d.rows.length+5;row+=4){
 const end=Math.min(row+4,d.rows.length+5);
 for(const [part,range] of [['left',`A${row}:F${end}`],['right',`G${row}:J${end}`]]){
 const image=await w.render({sheetName:'Current_RAID',range,scale:1,format:'png'});await fs.writeFile(root+`/qa/tahap8/current_${row}_${part}.png`,new Uint8Array(await image.arrayBuffer()));
 }}
for(const [name,range] of [['Gate_Updates','A1:H9'],['Change_Log',`A1:F${d.events.length+5}`],['Overview','A29:B33']]){
const image=await w.render({sheetName:name,range,scale:1,format:'png'});await fs.writeFile(root+`/qa/tahap8/${name}.png`,new Uint8Array(await image.arrayBuffer()));}
const scan=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:50},maxChars:1500});
await fs.writeFile(root+'/qa/tahap8/raid_error_scan.ndjson',scan.ndjson);
await(await SpreadsheetFile.exportXlsx(w)).save(out+'/11_RAID_Risk_Governance.xlsx');
console.log(JSON.stringify({preserved,current_rows:d.rows.length,exported:true}));
