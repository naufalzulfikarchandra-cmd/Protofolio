from pathlib import Path
import json,csv,copy,hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs/tahap8';O.mkdir(exist_ok=True,parents=True)
old=json.loads((R/'outputs/tahap4/raid_data.json').read_text());rows=copy.deepcopy(old['rows'])
updates={
'R01':('Kontrol teknis diterapkan; as of belum terverifikasi','Tujuh fitur bulan 1 dan 2, split per proyek dan outcome terpisah sudah ada. G01 HOLD karena pembekuan baseline dan generator belum terbukti.','Periksa provenance dan as of sesuai usulan Opsi B sebelum keputusan kelayakan.','Tahap 5 audit dan protocol; Tahap 7 brief'),
'R02':('Mitigasi pelaporan diterapkan; review owner terbuka','Demo 20% memuat 56 prioritas. RF menangkap 44 kasus dan aturan 39 dari 188 kasus terlambat. Interval selisih recall mencakup nol.','Pertahankan metrik beban review dan ketidakpastian, tanpa klaim manfaat operasional.','Tahap 5 capacity_scenarios dan uncertainty'),
'R03':('Label simulasi diterapkan; penerimaan narasi belum ada','Nama AI Project Risk Monitoring dipakai pada artefak terkini. Portofolio menyebut proyek independen dengan bantuan AI.','Owner meninjau narasi sebelum dipakai dalam lamaran.','Instruksi penamaan; Tahap 7 dan Tahap 8'),
'I01':('Terbuka pada kelayakan data','PV SPI SV telah dikeluarkan dari model baru. Temuan 2448 proyek tetap bagian audit, sedangkan bukti EV AC as of belum tersedia.','Jangan membuka G01 hanya karena PV dikeluarkan.','Tahap 5 audit dan protocol'),
'I02':('Hasil legacy tidak digunakan; model baru terdokumentasi','Training lama belum dipulihkan. Tahap 5 menghasilkan pipeline, manifest split, model dan evaluasi baru.','Gunakan artefak baru untuk reproduksi; jangan menggabungkan skor legacy.','Tahap 5 pipeline dan ZIP Colab user'),
'I03':('Keunggulan model baru juga belum konklusif','Legacy 46 vs 44 berbeda dari RF baru 44 vs 39. Evaluasi baru tidak membuktikan superioritas operasional.','Tampilkan hasil RF baru bersama pembanding dan interval ketidakpastian.','Tahap 5 test dan uncertainty; Tahap 7 status'),
'I04':('Batas delapan tahap diterapkan; penerimaan belum ada','Tahap 1 sampai 7 disusun bertahap. Tahap 8 kini diotorisasi. Audit tambahan Opsi B dan training baru belum dijalankan.','Jaga pemisahan log AI, RAID, keputusan dan actual pekerjaan.','Percakapan dan log Tahap 7'),
'A01':('Belum terverifikasi','Model baru memakai tujuh fitur bulan 1 dan 2. Definisi waktu tersedia EV AC, budget dan durasi belum terbukti.','Laksanakan pemeriksaan jika ditugaskan; catat gap sebagai gap.','Tahap 5 protocol; Tahap 7 brief Opsi B'),
'A02':('Asumsi baseline dipertahankan','93 jam dan 31 hari kerja adalah baseline SIM, 3 jam per hari. Belum ada log jam aktual setara.','Review kapasitas bila perubahan lingkup dijadwalkan; jangan mengarang actual.','Planning dan budget baseline'),
'A03':('Sebagian alat tersedia; uji perangkat owner belum lengkap','Dashboard HTML mandiri tersedia. GitHub terhubung tetapi tidak ada repository yang terlihat dan browser meminta login.','Lengkapi UAT Windows dan akses repository tanpa menganggap koneksi akun cukup.','Tahap 6 HTML dan pemeriksaan akses 6 November'),
'A04':('Proxy lama tetap berlaku untuk estimasi','Tarif Tahap 3 dibekukan. Usulan Opsi B memakai rate tersebut dan bukan quote baru atau pembayaran.','Validasi sebelum realisasi dan rekonsiliasi overlap rework.','Laporan budget dan brief Tahap 7'),
'D01':('Digantikan oleh lingkup HTML','User mengganti keluaran dashboard menjadi HTML. Dashboard dan notebook HTML tersedia, sehingga Power BI bukan dependency keluaran terkini.','Pakai HTML dan simpan riwayat keputusan alat.','Instruksi user; keputusan Tahap 6 HTML'),
'D02':('Terbuka menunggu UAT dan penerimaan','21 uji DOM dan eksekusi notebook dengan mock tersedia. UAT Windows owner dan sign off belum tercatat.','Jalankan checklist UAT dan simpan bukti owner sebelum penerimaan.','Tahap 6 verification; Tahap 7 status')}
for row in rows:
 status,event,action,src=updates[row[0]];row[3]=event;row[4]=src;row[5]=status;row[8]=action
rows.extend([
['I05','Issue','Uji browser dan business UAT belum lengkap','Bukti yang ada adalah DOM dan mock Colab. Belum ada penerimaan business user Windows.','Tahap 6 verification dan Tahap 7 status','Terbuka','PM Business User dan QA','Naufal','Lengkapi checklist UAT yang menyimpan hasil dan bukti, tanpa auto sign off.','KAN-32 KAN-36'],
['I06','Issue','Forecast belum direkonsiliasi setelah perubahan alat','EAC Rp20140066,625 masih snapshot SIM 27 Januari. Perubahan HTML dan dampak bersih Opsi B belum dihitung.','Tahap 3 budget dan Tahap 7 brief','Terbuka','Finance Reviewer dan PMO','Naufal','Petakan actual SIM dan remaining rework sebelum forecast baru, hindari penambahan ganda.','KAN-21 KAN-34 KAN-36'],
['D03','Dependency','Repository tujuan diperlukan untuk unggah GitHub','Akun terhubung naufalzulfikarchandra-cmd, repository yang terlihat kosong. Koneksi tidak menyediakan pembuatan repo. Login Google untuk GitHub menampilkan Something went wrong.','Pemeriksaan akun dan hasil login 6 November 2026','Terbuka menunggu repository tujuan','Operations Owner','Naufal','Owner dapat membuat repository berisi README lalu memberikan URL agar koneksi GitHub dapat mengunggah paket.','KAN-38']])
gates=[
['G01','Kelayakan data dan model','HOLD','Split dan evaluasi tersedia; semantic as of dan freeze belum terbukti.','Data Owner dan Technical Lead','Naufal','Bukti waktu tersedia fitur dan keputusan penggunaan model','Tahap 5 audit dan protocol'],
['G02','Security dan akses','Belum disetujui','Paket diperiksa sebelum distribusi. Pemeriksaan berkas bukan persetujuan security reviewer.','Security Reviewer','Naufal','Daftar sumber, hasil pemeriksaan paket dan review owner','Tahap 8 pemeriksaan paket'],
['G03','Business UAT','Belum diterima','DOM dan mock notebook lulus. Owner Windows UAT belum tercatat.','PM Business User','Naufal','Checklist UAT dengan hasil, tanggal dan bukti','Tahap 6 verification; checklist Tahap 8'],
['G04','Readiness dan handover','Menunggu penerimaan owner','Dokumen handover inti dan RAID telah tersimpan di Drive. Distribusi GitHub belum selesai. Unggah berkas bukan approval produksi.','Operations Owner','Naufal','Berkas final, tautan hasil, runbook dan review klaim','Tahap 8 handover dan log']]
events=[
['EV8-01','2026-11-06','R01 I01 A01','Audit dan model Tahap 5 sudah tersedia, gate tetap HOLD','Temuan as of belum ditutup','Tahap 5 audit dan protocol'],
['EV8-02','2026-11-06','R02 I03','Hasil terkini RF 44 vs CPI39 pada top56','Bukan legacy46 vs44, keunggulan belum konklusif','Tahap 5 capacity dan uncertainty'],
['EV8-03','2026-11-06','D01','HTML menggantikan Power BI atas instruksi user','Dependency Power BI digantikan, riwayat tidak dihapus','Tahap 6 HTML decision record'],
['EV8-04','2026-11-06','D02 I05','Uji DOM dan mock tersedia, UAT owner belum tercatat','Tidak menandai gate lolos','Tahap 6 dan 7 verification'],
['EV8-05','2026-11-06','I06 A04','Forecast lama dan usulan audit B memiliki kemungkinan overlap','EAC tidak ditambah otomatis','Tahap 7 brief dan budget'],
['EV8-06','2026-11-06','D03','GitHub terhubung tetapi repo belum tersedia dan browser perlu login','Unggah GitHub menunggu akses, paket tetap disiapkan','Pemeriksaan akun dan browser'],
['EV8-07','2026-11-06','R03 I04','User mengotorisasi Tahap 8 beserta Drive GitHub Jira RAID','Batas klaim dan review owner dipertahankan','Instruksi user saat ini'],
['EV8-08','2026-11-06','D03','Login Google untuk GitHub menampilkan Something went wrong','Tidak mengklaim repository atau unggah GitHub berhasil','Hasil autentikasi browser'],
['EV8-09','2026-11-06','D02 R03','Dokumen handover inti dan RAID tersimpan di Drive','Ketersediaan berkas tetap terpisah dari penerimaan owner','Hasil unggah dan metadata Google Drive']]
payload={'project':'AI Project Risk Monitoring','actual_update_date':'2026-11-06','legacy_snapshot_sim':'2027-01-21','rows':rows,'gates':gates,'events':events,'legacy_sha256':hashlib.sha256((R/'outputs/tahap4/11_RAID_Risk_Governance.xlsx').read_bytes()).hexdigest(),'no_residual_rescore':True}
(O/'raid_current.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False))
for name,headers,data in [('RAID_Current.csv',['ID','Jenis','Catatan','Bukti terkini','Sumber','Status terkini','Owner simulasi','PIC aktual','Tindak lanjut','Jira terkait'],rows),('Gate_Current.csv',['ID','Gate','Status','Bukti','Owner simulasi','PIC aktual','Syarat penerimaan','Sumber'],gates),('RAID_Change_Log.csv',['Event','Tanggal aktual','ID terkait','Perubahan berbasis bukti','Dampak','Sumber'],events)]:
 with (O/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(headers);w.writerows(data)
print('RAID rows',len(rows),'events',len(events),'gates',len(gates))
