# Sumber dan hak penggunaan

## Dataset

Reyhane Hajihoseyni (2026). Simulated project risk and earned value dataset, version 1. Mendeley Data. DOI 10.17632/2p5sz57wh2.1. https://data.mendeley.com/datasets/2p5sz57wh2/1 . Lisensi sumber CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Halaman metadata diperiksa 6 November 2026.

Data sumber merupakan benchmark sintetis. Tiga berkas yang dipakai adalah project_risk_raw_dataset.csv, simulated_project_ev_metrics_final.csv.xlsx dan project_delay_cost_overrun_summary_final.csv.xlsx. Paket mempertahankan byte sumber yang dipakai dalam eksperimen. Halaman metadata tidak menjadi bukti bahwa generator atau waktu tersedia fitur telah diaudit. Hash sumber ada pada results/stage5/environment.json.

Transformasi proyek mencakup parsing XLSX berisi CSV satu kolom, pembentukan snapshot akhir bulan 2 untuk proyek IT, feature engineering, split proyek, pelatihan benchmark terdahulu dan keluaran evaluasi. Penulis dataset tidak memberi endorsement atas proyek ini. Atribusi dan lisensi sumber harus dipertahankan saat dataset dibagikan ulang.

## Kode dan dokumen

Naufal Zulfikar Chandra mengarahkan proyek portofolio dengan bantuan AI untuk penulisan, kode dan analisis. Tidak ada lisensi perangkat lunak baru yang dipilih atas nama owner dalam penugasan ini. Lisensi dataset tidak otomatis menjadi lisensi seluruh repository. Dependensi tetap memakai ketentuan penerbit masing masing.

## Anggaran dan praktik dokumentasi

Basis benchmark biaya dan keterbatasannya tersedia pada docs/tahap3/10_Laporan_Budget_dan_Log.md. Tarif merupakan snapshot lama, bukan harga yang ditawarkan ulang. Rujukan lessons learned ada pada source register Tahap 7. Panduan README GitHub: https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes .
