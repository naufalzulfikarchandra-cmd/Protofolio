"""Tahap 6: month-2 IT synthetic demo, 20% review capacity. No test tuning."""
from pathlib import Path
from io import BytesIO,StringIO
from zipfile import ZipFile
import json,hashlib,math,platform,warnings
import pandas as pd
import numpy as np
import sklearn,joblib
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.calibration import CalibratedClassifierCV

FEATURES=['planned_months','log_budget','earned_fraction_m2','spent_fraction_m2','cpi_m2','earned_delta_fraction','spent_delta_fraction']
REQUIRED=['Project_ID','Project_Type','Planned_Budget_USD','Planned_Months','Snapshot_Month','EV_M1','AC_M1','EV_M2','AC_M2']

def decode(b):
    x=pd.read_excel(BytesIO(b),header=None,keep_default_na=False)
    if x.shape[1]==1:return pd.read_csv(StringIO('\n'.join(x[0].astype(str))),keep_default_na=False)
    return pd.read_excel(BytesIO(b),keep_default_na=False)

def get_bundle(path):
    with ZipFile(path) as z:
        # Read allowlisted members only; do not extract arbitrary archive paths.
        names=z.namelist()
        def pick(suffix):
            hits=[n for n in names if n==suffix or n.endswith('/'+suffix)]
            if len(hits)!=1:raise ValueError('ZIP must contain exactly one '+suffix)
            return z.read(hits[0])
        env=json.loads(pick('results/environment.json'))
        protocol=json.loads(pick('protocol.json'))
        card=json.loads(pick('model/model_card.json'))
        snap=pd.read_csv(BytesIO(pick('data/snapshot_month2.csv')))
        split=pd.read_csv(BytesIO(pick('data/split_manifest.csv')))
        if card['features']!=FEATURES or card['snapshot_month']!=2 or card['selected']!='RF_depth4':
            raise ValueError('Unsupported model contract; expected locked month-2 RF_depth4')
        if not snap.Project_ID.is_unique or not split.Project_ID.is_unique:raise ValueError('Duplicate snapshot/split key')
        if set(snap.Project_ID)!=set(split.Project_ID):raise ValueError('Split IDs do not match snapshot')
        joined=snap.drop(columns=['split'],errors='ignore').merge(split[['Project_ID','split']],on='Project_ID',validate='one_to_one')
        modelbytes=pick('model/exploratory_model.joblib')
        mismatch={k:{'training':v,'runtime':{'numpy':np.__version__,'pandas':pd.__version__,'scikit-learn':sklearn.__version__,'joblib':joblib.__version__}.get(k)} for k,v in env['packages'].items() if v!={'numpy':np.__version__,'pandas':pd.__version__,'scikit-learn':sklearn.__version__,'joblib':joblib.__version__}.get(k)}
        if not mismatch and platform.python_version().split('.')[:2]==env['python'].split('.')[:2]:
            model=joblib.load(BytesIO(modelbytes))
            mode='loaded_matching_environment'
        else:
            # Reproduce selected model only on original TRAIN IDs. No selection/tuning on test.
            train=joined[joined.split.eq('train')]
            if len(train)!=828:raise ValueError('Original train count must be 828')
            if train.delayed.nunique()!=2:raise ValueError('Training labels invalid')
            estimator=Pipeline([('impute',SimpleImputer(strategy='median')),('model',RandomForestClassifier(n_estimators=200,max_depth=4,min_samples_leaf=10,n_jobs=1,random_state=20261104))])
            model=CalibratedClassifierCV(estimator,method='sigmoid',cv=StratifiedKFold(3,shuffle=True,random_state=20261104),n_jobs=1)
            # Original train order matters for calibration-fold membership: reconstruct deterministic split.
            from sklearn.model_selection import train_test_split
            ordered=joined.sort_values('Project_ID').reset_index(drop=True)
            trainval,test=train_test_split(ordered,test_size=.2,stratify=ordered.delayed,random_state=20261104)
            train,val=train_test_split(trainval,test_size=.25,stratify=trainval.delayed,random_state=20261104)
            for frame,name in [(train,'train'),(val,'validation'),(test,'test')]:
                if set(frame.Project_ID)!=set(split.loc[split.split.eq(name),'Project_ID']):raise ValueError('Split reproduction mismatch')
            model.fit(train[FEATURES],train.delayed)
            mode='reproduced_locked_model_for_runtime_compatibility'
        raw=pd.read_csv(BytesIO(pick('source/project_risk_raw_dataset.csv')),keep_default_na=False)
        ev=decode(pick('source/simulated_project_ev_metrics_final.csv.xlsx'))
        historical=pd.read_csv(BytesIO(pick('results/test_predictions.csv')))
        trace={'model_load_mode':mode,'mismatched_packages':mismatch,'original_python':env['python'],'runtime_python':platform.python_version(),
          'parent_model_sha256':hashlib.sha256(modelbytes).hexdigest(),'features':FEATURES,'original_test_used_for_tuning':False,
          'runtime_packages':{'numpy':np.__version__,'pandas':pd.__version__,'scikit-learn':sklearn.__version__,'joblib':joblib.__version__},
          'gate':'HOLD','capacity_fraction':.2,'source':'Mendeley 10.17632/2p5sz57wh2.1; CC BY 4.0; synthetic'}
    return model,raw,ev,historical,trace

def demo_input(raw,ev,historical):
    ids=historical.Project_ID.tolist()
    d=raw.set_index('Project_ID').loc[ids]
    m1=ev[ev.Month.eq(1)].set_index('Project_ID').loc[ids]
    m2=ev[ev.Month.eq(2)].set_index('Project_ID').loc[ids]
    return pd.DataFrame({'Project_ID':ids,'Project_Type':d.Project_Type.to_numpy(),
       'Planned_Budget_USD':d.Project_Budget_USD.to_numpy(),'Planned_Months':d.Estimated_Timeline_Months.to_numpy(),
       'Snapshot_Month':2,'EV_M1':m1.EV.to_numpy(),'AC_M1':m1.AC.to_numpy(),'EV_M2':m2.EV.to_numpy(),'AC_M2':m2.AC.to_numpy()})

def validate_and_predict(df,model,run_id='DEMO_M2_20',capacity=.2):
    if not 0<capacity<=1:raise ValueError('Capacity must be >0 and <=1')
    missing=[c for c in REQUIRED if c not in df]
    if missing:raise ValueError('Missing required columns: '+', '.join(missing))
    x=df[REQUIRED].copy().reset_index(drop=True)
    reasons=[[] for _ in range(len(x))]
    def mark(mask,reason):
        for i in np.flatnonzero(np.asarray(mask)):reasons[i].append(reason)
    x['Project_ID']=x.Project_ID.fillna('').astype(str).str.strip()
    mark(x.Project_ID.eq(''),'ID kosong')
    mark(x.Project_ID.duplicated(keep=False),'ID duplikat dalam batch')
    mark(~x.Project_Type.eq('IT'),'Sektor di luar IT')
    for c in REQUIRED[2:]:
        x[c]=pd.to_numeric(x[c],errors='coerce')
        mark(~np.isfinite(x[c]),c+' bukan angka finite')
    mark(x.Planned_Budget_USD.le(0),'Budget harus positif')
    mark(x.Planned_Months.le(2),'Durasi rencana tidak mendukung snapshot bulan 2')
    mark(~x.Snapshot_Month.eq(2),'Hanya snapshot bulan 2 yang didukung')
    for c in ['EV_M1','AC_M1','EV_M2','AC_M2']:mark(x[c].le(0),c+' harus positif')
    mark(x.EV_M2.lt(x.EV_M1)|x.AC_M2.lt(x.AC_M1),'Kumulatif bulan 2 turun')
    mark(x.EV_M2.ge(x.Planned_Budget_USD),'EV sudah mencapai budget; di luar cohort')
    good=np.array([not r for r in reasons])
    rejected=x.loc[~good,['Project_ID']].copy()
    rejected['Error']=['; '.join(reasons[i]) for i in np.flatnonzero(~good)]
    rejected['Run_ID']=run_id
    v=x.loc[good].copy(); b=v.Planned_Budget_USD
    f=pd.DataFrame({'planned_months':v.Planned_Months,'log_budget':np.log1p(b),'earned_fraction_m2':v.EV_M2/b,
       'spent_fraction_m2':v.AC_M2/b,'cpi_m2':v.EV_M2/v.AC_M2,'earned_delta_fraction':(v.EV_M2-v.EV_M1)/b,
       'spent_delta_fraction':(v.AC_M2-v.AC_M1)/b})
    if len(v):scores=model.predict_proba(f[FEATURES])[:,1]
    else:scores=np.array([])
    v['Risk_Score']=scores;v['CPI_M2']=v.EV_M2/v.AC_M2
    v=v.sort_values(['Risk_Score','Project_ID'],ascending=[False,True]).reset_index(drop=True)
    v['Review_Rank']=np.arange(1,len(v)+1)
    k=math.ceil(len(v)*capacity)
    v['Selected_For_Review']=v.Review_Rank.le(k)
    v['Run_ID']=run_id;v['Model_Version']='RF4_M2_calibrated_locked';v['Gate']='HOLD'
    v['Data_Mode']='Historical synthetic test replay'
    v['Review_Group']=np.where(v.Selected_For_Review,f'Prioritas {capacity:.0%}','Di luar kapasitas')
    summary={'run_id':run_id,'received':len(x),'accepted':len(v),'rejected':len(rejected),'capacity_fraction':capacity,'review_count':k,
      'received_equals_accepted_plus_rejected':len(x)==len(v)+len(rejected),'gate':'HOLD','data_mode':'Synthetic replay; no claim of new independent performance'}
    return v,rejected,summary

def run_stage6(zip_path,output,custom_csv=None):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    model,raw,ev,historical,trace=get_bundle(zip_path)
    original=demo_input(raw,ev,historical)
    original.to_csv(output/'template_demo_input.csv',index=False)
    if custom_csv is None:
        # Three explicitly invalid QA fixtures, not fictitious project incidents.
        fixtures=pd.concat([original.head(1)]*3,ignore_index=True)
        fixtures['Project_ID']=['QA_INVALID_COST','QA_INVALID_MONTH','QA_MISSING_EV']
        fixtures.loc[0,'AC_M2']=0;fixtures.loc[1,'Snapshot_Month']=3;fixtures.loc[2,'EV_M1']=np.nan
        incoming=pd.concat([original,fixtures],ignore_index=True)
    else:incoming=pd.read_csv(custom_csv)
    incoming.to_csv(output/'batch_input.csv',index=False)
    scored,rejected,summary=validate_and_predict(incoming,model)
    if custom_csv is not None:
        scored['Data_Mode']='User-supplied synthetic demo; outcomes unknown'
        summary['data_mode']='User-supplied demo; no outcome evaluation'
    for name,frame in [('predictions.csv',scored),('rejected_rows.csv',rejected)]:frame.to_csv(output/name,index=False)
    # Draft review workload, NOT completed mitigation, RAID events or UAT sign-off.
    actions=scored.loc[scored.Selected_For_Review,['Project_ID','Review_Rank','Risk_Score']].copy()
    actions['Review_Status']='Belum direview';actions['Owner']='';actions['Due_Date']='';actions['Decision']='';actions['Record_Type']='Draft review queue'
    actions.to_csv(output/'review_queue_draft.csv',index=False)
    if custom_csv is None:
        merged=scored.merge(historical[['Project_ID','model_score','delayed']],on='Project_ID',validate='one_to_one')
        delta=float(np.max(np.abs(merged.Risk_Score-merged.model_score)))
        trace['replay_max_absolute_score_difference']=delta
        trace['replay_scores_match_original']=bool(delta<1e-8)
        # Outcomes are attached only AFTER scoring, in separate historical evaluation file.
        merged.to_csv(output/'historical_reconciliation.csv',index=False)
        summary['historical_selected_hits']=int(merged.loc[merged.Selected_For_Review,'delayed'].sum())
    joblib.dump(model,output/'runtime_model.joblib')
    for name,obj in [('run_summary.json',summary),('model_trace.json',trace)]:
        (output/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    return model,original,scored,rejected,summary,trace
