from pathlib import Path
import json,copy
import pandas as pd,numpy as np

def records(df):
    return [{k:None if pd.isna(v) else v.item() if isinstance(v,np.generic) else v for k,v in r.items()} for r in df.to_dict('records')]

def render_html(results_dir,base_data,template,output_path,replay=True):
    results_dir=Path(results_dir)
    data=copy.deepcopy(base_data)
    pred=pd.read_csv(results_dir/'predictions.csv')
    risks=pred.rename(columns={'Planned_Budget_USD':'Budget_USD','Planned_Months':'Duration_Months'})
    data['risk']=records(risks)
    data['inputs']=records(pred)
    data['summary']=json.loads((results_dir/'run_summary.json').read_text())
    data['errors']=records(pd.read_csv(results_dir/'rejected_rows.csv'))
    data['metadata']['data_mode']='Historical synthetic test replay' if replay else 'User imported demo'
    data['metadata']['html_generated_from_batch']=True
    encoded=json.dumps(data,ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    if template.count('__DASHBOARD_DATA__')!=1:raise ValueError('Invalid HTML template')
    Path(output_path).write_text(template.replace('__DASHBOARD_DATA__',encoded),encoding='utf-8')
    return data
