"""Reproducible Phase 5 synthetic benchmark. Run from this package directory.
No purchases, network, external services, XGBoost, deployment, or batch integration.
"""
from pathlib import Path
import argparse, contextlib, hashlib, io, json, math, platform, sys
import numpy as np
import pandas as pd
import sklearn, joblib
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.metrics import (average_precision_score, roc_auc_score, brier_score_loss,
    precision_score, recall_score, f1_score, confusion_matrix)

BASE = Path(__file__).resolve().parent
RAW_NAME = 'project_risk_raw_dataset.csv'
EV_NAME = 'simulated_project_ev_metrics_final.csv.xlsx'
SUMMARY_NAME = 'project_delay_cost_overrun_summary_final.csv.xlsx'

def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')

def read_table(path):
    if path.suffix.lower() == '.csv':
        return pd.read_csv(path, keep_default_na=False)
    frame = pd.read_excel(path, header=None, keep_default_na=False)
    if frame.shape[1] == 1 and 'Project_ID,' in str(frame.iloc[0, 0]):
        return pd.read_csv(io.StringIO('\n'.join(frame.iloc[:, 0].astype(str))), keep_default_na=False)
    return pd.read_excel(path, keep_default_na=False)

def ranked_indices(ids, score):
    return np.lexsort((np.asarray(ids, dtype=str), -np.asarray(score)))

def rank_metrics(ids, y, score, fraction):
    y = np.asarray(y)
    k = int(math.ceil(len(y) * fraction))
    chosen = ranked_indices(ids, score)[:k]
    hits = int(y[chosen].sum())
    return {'capacity_fraction': fraction, 'n': len(y), 'late': int(y.sum()),
            'k': k, 'hits': hits, 'precision_at_k': hits/k,
            'recall_at_k': hits/int(y.sum()), 'false_alerts_at_k': k-hits}

def metrics(y, score, pred, probability=True):
    return {'n':len(y), 'late':int(np.sum(y)), 'alerts':int(np.sum(pred)),
            'precision':float(precision_score(y,pred,zero_division=0)),
            'recall':float(recall_score(y,pred,zero_division=0)),
            'f1':float(f1_score(y,pred,zero_division=0)),
            'average_precision':float(average_precision_score(y,score)),
            'roc_auc':float(roc_auc_score(y,score)),
            'brier':float(brier_score_loss(y,score)) if probability else None,
            'confusion_matrix_TN_FP_FN_TP':confusion_matrix(y,pred,labels=[0,1]).ravel().tolist()}

def audit_sources(raw, ev, summary):
    assert raw.Project_ID.is_unique and summary.Project_ID.is_unique, 'Duplicate project IDs'
    assert set(raw.Project_ID)==set(ev.Project_ID)==set(summary.Project_ID), 'ID sets differ'
    assert not ev.duplicated(['Project_ID','Month']).any(), 'Duplicate monthly key'
    assert (summary.Schedule_Delay == summary.Actual_Duration_Months-summary.Estimated_Timeline_Months).all()
    assert np.allclose(summary.Cost_Overrun,summary.Actual_Cost-summary.Planned_Budget)
    j=raw[['Project_ID','Project_Budget_USD','Estimated_Timeline_Months']].merge(summary,on='Project_ID',suffixes=('_raw','_summary'),validate='one_to_one')
    assert np.allclose(j.Project_Budget_USD,j.Planned_Budget)
    assert (j.Estimated_Timeline_Months_raw==j.Estimated_Timeline_Months_summary).all()
    e=ev.merge(summary,on='Project_ID',suffixes=('_ev','_summary'),validate='many_to_one')
    for c in ['Estimated_Timeline_Months','Actual_Duration_Months','Planned_Budget','Actual_Cost']:
        assert np.allclose(e[c+'_ev'], e[c+'_summary']), c+' inconsistent'
    assert (ev[['PV','EV','AC','Planned_Budget']]>0).all().all()
    assert all(g.Month.tolist()==list(range(1,len(g)+1)) for _,g in ev.sort_values(['Project_ID','Month']).groupby('Project_ID'))
    at_end=ev[ev.Month.eq(ev.Estimated_Timeline_Months)].merge(summary[['Project_ID','Schedule_Delay']],on='Project_ID')
    late=at_end[at_end.Schedule_Delay.gt(0)]
    delta=ev.sort_values(['Project_ID','Month']).copy()
    for col in ['PV','EV','AC']:
        delta['d'+col]=delta.groupby('Project_ID')[col].diff().fillna(delta[col])
    return {'rows':{'raw':len(raw),'monthly':len(ev),'summary':len(summary)},
      'unique_project_and_monthly_keys':True, 'id_sets_match':True, 'label_duration_consistent':True,
      'cost_budget_duration_reconciliation':True,
      'late_projects_at_planned_end':len(late),
      'late_PV_below_budget_at_planned_end':int((late.PV<late.Planned_Budget-1e-6).sum()),
      'cpi_cumulative_matches_EV_AC':bool(np.allclose(ev.CPI_Cumulative,ev.EV/ev.AC)),
      'spi_cumulative_matches_EV_PV':bool(np.allclose(ev.SPI_Cumulative,ev.EV/ev.PV)),
      'monthly_SPI_not_raw_increment_ratio':int((~np.isclose(delta.SPI_Monthly,delta.dEV/delta.dPV)).sum()),
      'monthly_SPI_matches_clipped_increment_ratio':bool(np.allclose(delta.SPI_Monthly,(delta.dEV/delta.dPV).clip(.6,1.4))),
      'literal_None_preserved_not_missing':{c:int(raw[c].eq('None').sum()) for c in ['Tech_Environment_Stability','Change_Control_Maturity','Risk_Management_Maturity']},
      'literal_NA_unresolved_semantics':{'Tech_Environment_Stability':int(raw.Tech_Environment_Stability.eq('N/A').sum()),'note':'N/A may mean not applicable or unavailable; preserved literally, not imputed or used as predictor'},
      'empty_cells':{'raw':int(raw.eq('').sum().sum()),'monthly':int(ev.eq('').sum().sum()),'summary':int(summary.eq('').sum().sum())},
      'asof_status':'UNVERIFIED: generator code and baseline freeze history unavailable; monthly features provisional synthetic measurements only',
      'operational_gate':'HOLD'}

def prepare(raw,ev,summary):
    # Exact month slices ONLY. Never group all future observations into predictors.
    m1=ev[ev.Month.eq(1)][['Project_ID','EV','AC']].rename(columns={'EV':'EV1','AC':'AC1'})
    m2=ev[ev.Month.eq(2)][['Project_ID','EV','AC']].rename(columns={'EV':'EV2','AC':'AC2'})
    base=raw.loc[raw.Project_Type.eq('IT'),['Project_ID','Project_Budget_USD','Estimated_Timeline_Months']].copy()
    joined=base.merge(m1,on='Project_ID',validate='one_to_one').merge(m2,on='Project_ID',validate='one_to_one')
    eligible=joined.Estimated_Timeline_Months.gt(2)&joined.EV2.lt(joined.Project_Budget_USD)
    d=joined[eligible].copy().sort_values('Project_ID').reset_index(drop=True)
    b=d.Project_Budget_USD
    d['planned_months']=d.Estimated_Timeline_Months
    d['log_budget']=np.log1p(b)
    d['earned_fraction_m2']=d.EV2/b
    d['spent_fraction_m2']=d.AC2/b
    d['cpi_m2']=d.EV2/d.AC2
    d['earned_delta_fraction']=(d.EV2-d.EV1)/b
    d['spent_delta_fraction']=(d.AC2-d.AC1)/b
    # Outcome joined only AFTER feature computation; never selected by predictor list.
    labels=summary[['Project_ID','Schedule_Delay']].assign(delayed=lambda x:x.Schedule_Delay.gt(0).astype(int))
    d=d.merge(labels[['Project_ID','delayed']],on='Project_ID',validate='one_to_one')
    return d, {'IT_before_eligibility':len(base),'after_eligibility':len(d),'excluded':len(base)-len(d),'late':int(d.delayed.sum())}

def run(source_dir=None, output_dir=None, executor='Python runtime; operator identity not inferred'):
    source=Path(source_dir) if source_dir else BASE/'source'
    output=Path(output_dir) if output_dir else BASE
    for sub in ['data','results','model']: (output/sub).mkdir(parents=True,exist_ok=True)
    protocol=json.loads((BASE/'protocol.json').read_text(encoding='utf-8'))
    seed=protocol['seed']; features=protocol['features']
    raw,ev,summary=[read_table(source/n) for n in [RAW_NAME,EV_NAME,SUMMARY_NAME]]
    audit=audit_sources(raw,ev,summary)
    d,cohort=prepare(raw,ev,summary); audit['cohort']=cohort
    assert d.Project_ID.is_unique and np.isfinite(d[features].to_numpy()).all()
    trainval,test=train_test_split(d,test_size=.2,stratify=d.delayed,random_state=seed)
    train,val=train_test_split(trainval,test_size=.25,stratify=trainval.delayed,random_state=seed)
    frames={'train':train,'validation':val,'test':test}
    ids=[set(x.Project_ID) for x in frames.values()]
    assert not(ids[0]&ids[1] or ids[0]&ids[2] or ids[1]&ids[2])
    split=pd.concat([x[['Project_ID','delayed']].assign(split=k) for k,x in frames.items()]).sort_values('Project_ID')
    split.to_csv(output/'data/split_manifest.csv',index=False)
    d[['Project_ID']+features+['delayed']].merge(split[['Project_ID','split']],on='Project_ID',validate='one_to_one').to_csv(output/'data/snapshot_month2.csv',index=False)
    dump(output/'results/audit.json',audit)
    fitted={}; validation=[]
    for name in protocol['candidates']:
        if name.startswith('LR'):
            c=float(name.split('_C')[1])
            estimator=Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler()),
                ('model',LogisticRegression(C=c,max_iter=3000,random_state=seed))])
        else:
            depth=int(name.split('depth')[1])
            estimator=Pipeline([('impute',SimpleImputer(strategy='median')),
                ('model',RandomForestClassifier(n_estimators=200,max_depth=depth,min_samples_leaf=10,n_jobs=1,random_state=seed))])
        calibrated=CalibratedClassifierCV(estimator,method='sigmoid',cv=StratifiedKFold(3,shuffle=True,random_state=seed),n_jobs=1)
        calibrated.fit(train[features],train.delayed)
        p=calibrated.predict_proba(val[features])[:,1]
        validation.append({'method':name,**metrics(val.delayed,p,p>=.5)})
        fitted[name]=calibrated
    # Stable sort preserves LR/smaller-hyperparameter preference for exact AP ties.
    best=sorted(validation,key=lambda x:-x['average_precision'])[0]['method']
    model=fitted[best]
    rule_val=-val.cpi_m2.to_numpy()
    validation.append({'method':'CPI_rule',**metrics(val.delayed,rule_val,val.cpi_m2.lt(1),False)})
    pd.DataFrame(validation).drop(columns=['confusion_matrix_TN_FP_FN_TP']).to_csv(output/'results/validation_metrics.csv',index=False)
    # Selection locked before test is scored. No train+validation refit.
    selection={'selected':best,'criterion':'validation AP','split_counts':{k:len(x) for k,x in frames.items()},
      'validation_model_AP':next(x['average_precision'] for x in validation if x['method']==best),
      'validation_rule_AP':validation[-1]['average_precision'], 'operational_gate':'HOLD'}
    dump(output/'results/selection.json',selection)
    p=model.predict_proba(test[features])[:,1]; rule=-test.cpi_m2.to_numpy()
    prevalence=float(train.delayed.mean())
    evaluated=[{'method':best,**metrics(test.delayed,p,p>=.5)},
      {'method':'CPI_rule',**metrics(test.delayed,rule,test.cpi_m2.lt(1),False)},
      {'method':'Train_prevalence',**metrics(test.delayed,np.full(len(test),prevalence),np.full(len(test),prevalence>=.5))}]
    dump(output/'results/test_metrics.json',evaluated)
    pd.DataFrame(evaluated).drop(columns=['confusion_matrix_TN_FP_FN_TP']).to_csv(output/'results/test_metrics.csv',index=False)
    rankings=[]
    for fraction in [.1,.2,.3]:
        for name,score in [(best,p),('CPI_rule',rule)]:
            rankings.append({'method':name,**rank_metrics(test.Project_ID,test.delayed,score,fraction)})
    pd.DataFrame(rankings).to_csv(output/'results/capacity_scenarios.csv',index=False)
    predictions=test[['Project_ID','delayed','cpi_m2']].copy()
    predictions['model_score']=p; predictions['rule_score']=rule
    predictions['scope']='synthetic_test_only_not_new_operational_batch'
    predictions.sort_values('Project_ID').to_csv(output/'results/test_predictions.csv',index=False)
    frac_pos,mean_pred=calibration_curve(test.delayed,p,n_bins=5,strategy='quantile')
    pd.DataFrame({'mean_score':mean_pred,'observed_late_fraction':frac_pos}).to_csv(output/'results/calibration_bins.csv',index=False)
    rng=np.random.default_rng(seed); y=test.delayed.to_numpy(); arrids=test.Project_ID.to_numpy()
    diffs=[]
    for _ in range(2000):
        ix=rng.integers(0,len(y),len(y))
        if y[ix].sum()==0: continue
        # Duplicates are normal project bootstrap resampling. Same sample for both methods.
        a=rank_metrics(arrids[ix],y[ix],p[ix],.2)['recall_at_k']
        b=rank_metrics(arrids[ix],y[ix],rule[ix],.2)['recall_at_k']
        diffs.append(a-b)
    uncertainty={'paired_bootstrap_n':len(diffs),'recall_at_20pct_difference_interval95':np.quantile(diffs,[.025,.975]).tolist(),
      'note':'Internal synthetic test only. CI does not establish real-world or causal validity; ties use ID.'}
    dump(output/'results/uncertainty.json',uncertainty)
    # Persist a complete fitted preprocessing + calibration pipeline, not scores only.
    joblib.dump(model,output/'model/exploratory_model.joblib')
    loaded=joblib.load(output/'model/exploratory_model.joblib')
    assert np.allclose(p,loaded.predict_proba(test[features])[:,1])
    # Meaningful leakage regression: edits after month 2 must not change snapshot features.
    changed=ev.copy(); changed.loc[changed.Month.gt(2),['EV','AC']]*=1.5
    changed['Actual_Cost']=-999; changed['Actual_Duration_Months']=-999; changed['PV']=-999
    d2,_=prepare(raw,changed,summary)
    assert np.allclose(d[features],d2[features]) and d.Project_ID.equals(d2.Project_ID)
    assert list(model.feature_names_in_)==features
    checks={'source_reconciliation':True,'project_disjoint':True,'single_snapshot_per_project':True,
      'no_explicit_outcome_PV_SPI_or_ID_predictors':True,'future_row_and_forbidden_column_mutation_invariance':True,
      'reload_prediction_match':True,'feature_values_finite':True,'test_tuning':False,
      'semantic_asof_proven':False,'operational_gate_passed':False,
      'executor':executor}
    dump(output/'results/checks.json',checks)
    environment={'python':platform.python_version(),'platform':platform.platform(),
      'packages':{'numpy':np.__version__,'pandas':pd.__version__,'scikit-learn':sklearn.__version__,'joblib':joblib.__version__},
      'source_hashes':{n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in [RAW_NAME,EV_NAME,SUMMARY_NAME]},
      'protocol_sha256':hashlib.sha256((BASE/'protocol.json').read_bytes()).hexdigest(),
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    dump(output/'results/environment.json',environment)
    dump(output/'model/model_card.json',{'selected':best,'features':features,'snapshot_month':2,
      'population':'IT synthetic projects eligible at month 2','operational_status':'HOLD',
      'limitations':['Synthetic rule-based generator; no independent real-world test',
      'As-of and baseline frozen timestamps not verified','Only month 2, not all project ages',
      'USD units from source; not IDR PMO build budget','Scores not approved operational probabilities'],
      'train_only_fit':True,'seed':seed})
    print(json.dumps({'selected':best,'cohort':cohort,'splits':selection['split_counts'],'test':evaluated,
      'capacity':rankings,'uncertainty':uncertainty,'checks':checks},indent=2))
    return {'audit':audit,'selection':selection,'metrics':evaluated,'capacity':rankings,'uncertainty':uncertainty}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=BASE/'source')
    parser.add_argument('--output-dir',type=Path,default=BASE)
    parser.add_argument('--executor',default='Python runtime; operator identity not inferred')
    args=parser.parse_args()
    run(args.source_dir,args.output_dir,args.executor)
